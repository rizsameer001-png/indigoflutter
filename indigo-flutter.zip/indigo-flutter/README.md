# ✈️ IndiGo Clone — Flutter App

A production-quality Flutter mobile app connecting to the IndiGo Clone REST API.

---

## 📦 Project Structure

```
indigo_flutter/
├── lib/
│   ├── main.dart                        # App entry point & routing
│   ├── config/
│   │   ├── api_config.dart              # API base URL & endpoints
│   │   └── app_theme.dart              # Colors, typography, theme
│   ├── models/
│   │   ├── flight_model.dart           # Flight, Airport, FlightPrice
│   │   └── booking_model.dart          # Booking, Passenger, User
│   ├── services/
│   │   ├── api_service.dart            # Base HTTP client (GET/POST/PUT)
│   │   ├── auth_service.dart           # Login, register, logout
│   │   ├── flight_service.dart         # Search, status, fare calendar
│   │   ├── booking_service.dart        # Create, confirm, cancel, check-in
│   │   └── offer_service.dart          # Offers list
│   ├── providers/
│   │   ├── auth_provider.dart          # Auth state (ChangeNotifier)
│   │   └── booking_provider.dart       # Booking flow state
│   ├── screens/
│   │   ├── splash_screen.dart
│   │   ├── home_screen.dart            # Search + quick actions
│   │   ├── search_results_screen.dart  # Flight listings
│   │   ├── passenger_details_screen.dart
│   │   ├── addons_screen.dart
│   │   ├── payment_screen.dart
│   │   ├── confirmation_screen.dart
│   │   ├── manage_booking_screen.dart
│   │   ├── check_in_screen.dart
│   │   ├── flight_status_screen.dart
│   │   ├── offers_screen.dart
│   │   ├── my_bookings_screen.dart
│   │   ├── login_screen.dart
│   │   ├── register_screen.dart
│   │   └── profile_screen.dart
│   └── widgets/
│       ├── airport_picker.dart         # Bottom sheet airport selector
│       └── flight_card_widget.dart     # Reusable flight card
├── pubspec.yaml
└── README.md
```

---

## 🚀 Quick Start

### 1. Prerequisites
- Flutter SDK 3.0+
- Android Studio / Xcode
- IndiGo backend server running

### 2. Install dependencies
```bash
flutter pub get
```

### 3. Configure API URL in `lib/config/api_config.dart`

| Platform | URL |
|----------|-----|
| Android Emulator | `http://10.0.2.2:5000/api` |
| iOS Simulator | `http://localhost:5000/api` |
| Real Device | `http://YOUR_LAN_IP:5000/api` |

```dart
static const String baseUrl = 'http://10.0.2.2:5000/api';
```

### 4. Run the app
```bash
# Android
flutter run

# iOS
flutter run -d ios

# Specific device
flutter devices
flutter run -d <device_id>
```

---

## 📱 App Screens & Features

| Screen | Description |
|--------|-------------|
| Splash | Animated IndiGo branded loading screen |
| Home | Flight search (One Way / Round Trip), quick actions, offers |
| Search Results | Flight listing with sort (price/duration/departure) |
| Passenger Details | Multi-passenger form with meal preferences |
| Add-ons | Extra baggage, meal plan, seat, insurance, priority boarding |
| Payment | Card / UPI / Net Banking / Wallet + promo code |
| Confirmation | PNR display with next-step guidance |
| Manage Booking | Lookup & cancel by PNR |
| Web Check-In | Digital boarding pass generation |
| Flight Status | Real-time status by flight number |
| Offers | Promo codes with copy-to-clipboard |
| My Bookings | Full booking history (requires login) |
| Login / Register | JWT auth with token persistence |
| Profile | User info, loyalty points, tier display |

---

## 🔌 REST API Integration Map

### Auth APIs
```dart
// Login
ApiService.post('/auth/login', body: {'email': ..., 'password': ...})
// Register
ApiService.post('/auth/register', body: {firstName, lastName, email, password, phone})
// Get current user
ApiService.get('/auth/me', auth: true)
// Update profile
ApiService.put('/auth/profile', body: {...}, auth: true)
```

### Flight APIs
```dart
// Search flights
ApiService.get('/flights/search', params: {from, to, date, passengers, class, tripType})
// Flight status
ApiService.get('/flights/status', params: {flightNumber, date})
// Fare calendar (7 days)
ApiService.get('/flights/fare-calendar', params: {from, to})
// All airports
ApiService.get('/airports', params: {search?, popular?})
```

### Booking APIs
```dart
// Create booking
ApiService.post('/bookings', body: {flightId, passengers, class, contactEmail, contactPhone, addons?})
// Confirm payment
ApiService.post('/bookings/confirm-payment', body: {bookingId, paymentMethod, transactionId})
// Get by PNR
ApiService.get('/bookings/pnr/:pnr')
// My bookings
ApiService.get('/bookings/my-bookings', auth: true)
// Cancel
ApiService.put('/bookings/:id/cancel', body: {reason}, auth: true)
// Web check-in
ApiService.post('/bookings/check-in', body: {pnr, lastName})
```

### Offers APIs
```dart
// All offers
ApiService.get('/offers')
// Validate promo
ApiService.post('/offers/validate', body: {code, amount})
```

---

## 🗺️ Booking Flow

```
Home (search) 
  → SearchResultsScreen (select flight)
    → PassengerDetailsScreen (fill names + contact)
      → AddonsScreen (extra services)
        → PaymentScreen (pay + confirm)
          → ConfirmationScreen (PNR shown)
```

State is managed via `BookingProvider` (ChangeNotifier via Provider package). All booking data flows through this provider and is cleared after confirmation.

---

## 🛠️ Tech Stack

| Library | Usage |
|---------|-------|
| `provider` | State management |
| `http` | REST API calls |
| `shared_preferences` | Token & user caching |
| `intl` | Date & number formatting |
| `google_fonts` | Typography |
| `flutter_spinkit` | Loading indicators |

---

## 🔐 Authentication Flow

1. User logs in → JWT token saved to SharedPreferences
2. Every API call attaches `Authorization: Bearer <token>` header automatically via `ApiService`
3. On logout → token + user data cleared from SharedPreferences
4. `AuthProvider` exposes `isLoggedIn`, `user`, `loading` to all widgets

---

## 📋 Sample API Calls

### Search Flights
```dart
final result = await FlightService.searchFlights(
  from: 'DEL', to: 'BOM',
  date: '2025-12-15',
  passengers: 2,
  cabinClass: 'Economy',
  tripType: 'One Way',
);
// result['outbound'] → List<Flight>
```

### Create Booking
```dart
final res = await BookingService.createBooking(
  flightId: '...',
  passengers: [Passenger(title:'Mr', firstName:'Rahul', lastName:'Sharma', type:'Adult')],
  cabinClass: 'Economy',
  contactEmail: 'rahul@example.com',
  contactPhone: '9876543210',
  addons: {'mealPlan': true, 'extraBaggage': false},
);
```

---

## ✅ Build for Production

```bash
# Android APK
flutter build apk --release

# Android App Bundle (Play Store)
flutter build appbundle --release

# iOS (requires Mac + Xcode)
flutter build ios --release
```
