// lib/main.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'config/app_theme.dart';
import 'providers/auth_provider.dart';
import 'providers/booking_provider.dart';
import 'screens/splash_screen.dart';
import 'screens/home_screen.dart';
import 'screens/search_results_screen.dart';
import 'screens/passenger_details_screen.dart';
import 'screens/addons_screen.dart';
import 'screens/payment_screen.dart';
import 'screens/confirmation_screen.dart';
import 'screens/manage_booking_screen.dart';
import 'screens/check_in_screen.dart';
import 'screens/flight_status_screen.dart';
import 'screens/offers_screen.dart';
import 'screens/my_bookings_screen.dart';
import 'screens/login_screen.dart';
import 'screens/register_screen.dart';
import 'screens/profile_screen.dart';

void main() {
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthProvider()),
        ChangeNotifierProvider(create: (_) => BookingProvider()),
      ],
      child: const IndiGoApp(),
    ),
  );
}

class IndiGoApp extends StatelessWidget {
  const IndiGoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'IndiGo',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.theme,
      initialRoute: '/',
      routes: {
        '/':               (_) => const SplashScreen(),
        '/home':           (_) => const HomeScreen(),
        '/search-results': (_) => const SearchResultsScreen(),
        '/passengers':     (_) => const PassengerDetailsScreen(),
        '/addons':         (_) => const AddonsScreen(),
        '/payment':        (_) => const PaymentScreen(),
        '/confirmation':   (_) => const ConfirmationScreen(),
        '/manage-booking': (_) => const ManageBookingScreen(),
        '/check-in':       (_) => const CheckInScreen(),
        '/flight-status':  (_) => const FlightStatusScreen(),
        '/offers':         (_) => const OffersScreen(),
        '/my-bookings':    (_) => const MyBookingsScreen(),
        '/login':          (_) => const LoginScreen(),
        '/register':       (_) => const RegisterScreen(),
        '/profile':        (_) => const ProfileScreen(),
      },
    );
  }
}
