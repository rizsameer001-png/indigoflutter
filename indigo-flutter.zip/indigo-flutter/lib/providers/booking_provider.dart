// lib/providers/booking_provider.dart

import 'package:flutter/material.dart';
import '../models/flight_model.dart';
import '../models/booking_model.dart';

class BookingProvider extends ChangeNotifier {
  // Search params
  String from = '';
  String to = '';
  String fromCity = '';
  String toCity = '';
  String date = '';
  String? returnDate;
  int passengers = 1;
  String cabinClass = 'Economy';
  String tripType = 'One Way';

  // Selected flights
  Flight? selectedOutbound;
  Flight? selectedReturn;

  // Passenger details
  List<Passenger> passengerList = [];
  String contactEmail = '';
  String contactPhone = '';

  // Add-ons
  bool extraBaggage = false;
  bool mealPlan = false;
  bool seatSelection = false;
  bool travelInsurance = false;
  bool priorityBoarding = false;

  // Promo
  String? promoCode;
  double discount = 0;

  // Booking result
  String? createdBookingId;
  String? confirmedPNR;

  void setSearch({
    required String f, required String t,
    required String fc, required String tc,
    required String d, String? rd,
    required int pax, required String cls, required String trip,
  }) {
    from = f; to = t; fromCity = fc; toCity = tc;
    date = d; returnDate = rd; passengers = pax;
    cabinClass = cls; tripType = trip;
    notifyListeners();
  }

  void selectOutbound(Flight flight) {
    selectedOutbound = flight;
    notifyListeners();
  }

  void selectReturn(Flight flight) {
    selectedReturn = flight;
    notifyListeners();
  }

  void setPassengers(List<Passenger> list) {
    passengerList = list;
    notifyListeners();
  }

  void setContact(String email, String phone) {
    contactEmail = email;
    contactPhone = phone;
    notifyListeners();
  }

  void toggleAddon(String key) {
    switch (key) {
      case 'extraBaggage': extraBaggage = !extraBaggage; break;
      case 'mealPlan': mealPlan = !mealPlan; break;
      case 'seatSelection': seatSelection = !seatSelection; break;
      case 'travelInsurance': travelInsurance = !travelInsurance; break;
      case 'priorityBoarding': priorityBoarding = !priorityBoarding; break;
    }
    notifyListeners();
  }

  void applyPromo(String code, double disc) {
    promoCode = code;
    discount = disc;
    notifyListeners();
  }

  Map<String, bool> get addonsMap => {
    'extraBaggage': extraBaggage,
    'mealPlan': mealPlan,
    'seatSelection': seatSelection,
    'travelInsurance': travelInsurance,
    'priorityBoarding': priorityBoarding,
  };

  double get addonsCost {
    double total = 0;
    if (extraBaggage)    total += 599 * passengers;
    if (mealPlan)        total += 299 * passengers;
    if (seatSelection)   total += 199 * passengers;
    if (travelInsurance) total += 499 * passengers;
    if (priorityBoarding) total += 199 * passengers;
    return total;
  }

  double get totalPrice {
    if (selectedOutbound == null) return 0;
    final key = cabinClass.toLowerCase();
    double base = (key == 'business'
        ? selectedOutbound!.businessPrice.total
        : selectedOutbound!.economyPrice.total) * passengers;
    if (selectedReturn != null) {
      base += (key == 'business'
          ? selectedReturn!.businessPrice.total
          : selectedReturn!.economyPrice.total) * passengers;
    }
    return (base + addonsCost - discount).clamp(0, double.infinity);
  }

  void reset() {
    selectedOutbound = null;
    selectedReturn = null;
    passengerList = [];
    contactEmail = '';
    contactPhone = '';
    extraBaggage = mealPlan = seatSelection = travelInsurance = priorityBoarding = false;
    promoCode = null;
    discount = 0;
    createdBookingId = null;
    confirmedPNR = null;
    notifyListeners();
  }
}
