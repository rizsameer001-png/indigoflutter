// lib/providers/auth_provider.dart

import 'package:flutter/material.dart';
import '../services/auth_service.dart';
import '../models/booking_model.dart';

class AuthProvider extends ChangeNotifier {
  Map<String, dynamic>? _user;
  bool _loading = false;
  String? _error;

  Map<String, dynamic>? get user => _user;
  bool get isLoggedIn => _user != null;
  bool get loading => _loading;
  String? get error => _error;

  AuthProvider() {
    _init();
  }

  Future<void> _init() async {
    _user = await AuthService.getCachedUser();
    notifyListeners();
  }

  Future<bool> login(String email, String password) async {
    _loading = true;
    _error = null;
    notifyListeners();
    final data = await AuthService.login(email, password);
    _loading = false;
    if (data['success'] == true) {
      _user = data['user'];
      notifyListeners();
      return true;
    }
    _error = data['message'];
    notifyListeners();
    return false;
  }

  Future<bool> register({
    required String firstName,
    required String lastName,
    required String email,
    required String password,
    String? phone,
  }) async {
    _loading = true;
    _error = null;
    notifyListeners();
    final data = await AuthService.register(
      firstName: firstName,
      lastName: lastName,
      email: email,
      password: password,
      phone: phone,
    );
    _loading = false;
    if (data['success'] == true) {
      _user = data['user'];
      notifyListeners();
      return true;
    }
    _error = data['message'];
    notifyListeners();
    return false;
  }

  Future<void> logout() async {
    await AuthService.logout();
    _user = null;
    notifyListeners();
  }

  Future<void> refreshUser() async {
    final data = await AuthService.getMe();
    if (data['success'] == true) {
      _user = data['user'];
      notifyListeners();
    }
  }
}
