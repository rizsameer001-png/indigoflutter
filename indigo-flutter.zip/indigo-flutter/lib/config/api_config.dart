// lib/config/api_config.dart

class ApiConfig {
  // Android Emulator → use 10.0.2.2
  // iOS Simulator   → use localhost
  // Real Device     → use your machine's LAN IP e.g. 192.168.1.5
  static const String baseUrl = 'http://10.0.2.2:5000/api';

  // Auth
  static const String login    = '/auth/login';
  static const String register = '/auth/register';
  static const String me       = '/auth/me';
  static const String profile  = '/auth/profile';

  // Flights
  static const String flightSearch  = '/flights/search';
  static const String flightStatus  = '/flights/status';
  static const String fareCalendar  = '/flights/fare-calendar';
  static const String flights       = '/flights';

  // Airports
  static const String airports = '/airports';

  // Bookings
  static const String bookings        = '/bookings';
  static const String confirmPayment  = '/bookings/confirm-payment';
  static const String myBookings      = '/bookings/my-bookings';
  static const String checkIn         = '/bookings/check-in';

  // Offers
  static const String offers         = '/offers';
  static const String validatePromo  = '/offers/validate';
}
