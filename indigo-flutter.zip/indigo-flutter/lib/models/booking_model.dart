// lib/models/user_model.dart

class User {
  final String id;
  final String firstName;
  final String lastName;
  final String email;
  final String? phone;
  final int loyaltyPoints;
  final String tier;

  User({
    required this.id,
    required this.firstName,
    required this.lastName,
    required this.email,
    this.phone,
    required this.loyaltyPoints,
    required this.tier,
  });

  String get fullName => '$firstName $lastName';

  factory User.fromJson(Map<String, dynamic> j) => User(
    id: j['id'] ?? j['_id'] ?? '',
    firstName: j['firstName'] ?? '',
    lastName: j['lastName'] ?? '',
    email: j['email'] ?? '',
    phone: j['phone'],
    loyaltyPoints: j['loyaltyPoints'] ?? 0,
    tier: j['tier'] ?? 'Blue',
  );
}

// lib/models/booking_model.dart

class Passenger {
  final String title;
  final String firstName;
  final String lastName;
  final String type;
  final String? gender;
  final String? nationality;
  final String mealPreference;

  Passenger({
    required this.title,
    required this.firstName,
    required this.lastName,
    this.type = 'Adult',
    this.gender,
    this.nationality,
    this.mealPreference = 'None',
  });

  Map<String, dynamic> toJson() => {
    'title': title,
    'firstName': firstName,
    'lastName': lastName,
    'type': type,
    if (gender != null) 'gender': gender,
    if (nationality != null) 'nationality': nationality,
    'mealPreference': mealPreference,
  };

  factory Passenger.fromJson(Map<String, dynamic> j) => Passenger(
    title: j['title'] ?? 'Mr',
    firstName: j['firstName'] ?? '',
    lastName: j['lastName'] ?? '',
    type: j['type'] ?? 'Adult',
    gender: j['gender'],
    nationality: j['nationality'],
    mealPreference: j['mealPreference'] ?? 'None',
  );
}

class BookingPricing {
  final double baseFare;
  final double taxes;
  final double addons;
  final double discount;
  final double total;

  BookingPricing({
    required this.baseFare,
    required this.taxes,
    required this.addons,
    required this.discount,
    required this.total,
  });

  factory BookingPricing.fromJson(Map<String, dynamic> j) => BookingPricing(
    baseFare: (j['baseFare'] ?? 0).toDouble(),
    taxes: (j['taxes'] ?? 0).toDouble(),
    addons: (j['addons'] ?? 0).toDouble(),
    discount: (j['discount'] ?? 0).toDouble(),
    total: (j['total'] ?? 0).toDouble(),
  );
}

class Booking {
  final String id;
  final String pnr;
  final String status;
  final String cabinClass;
  final List<Passenger> passengers;
  final BookingPricing pricing;
  final Map<String, dynamic>? outboundFlight;
  final String? contactEmail;
  final String? contactPhone;
  final bool checkInStatus;

  Booking({
    required this.id,
    required this.pnr,
    required this.status,
    required this.cabinClass,
    required this.passengers,
    required this.pricing,
    this.outboundFlight,
    this.contactEmail,
    this.contactPhone,
    this.checkInStatus = false,
  });

  factory Booking.fromJson(Map<String, dynamic> j) => Booking(
    id: j['_id'] ?? '',
    pnr: j['pnr'] ?? '',
    status: j['status'] ?? 'Pending',
    cabinClass: j['class'] ?? 'Economy',
    passengers: (j['passengers'] as List? ?? [])
        .map((p) => Passenger.fromJson(p))
        .toList(),
    pricing: BookingPricing.fromJson(j['pricing'] ?? {}),
    outboundFlight: j['trip']?['outbound'],
    contactEmail: j['contactEmail'],
    contactPhone: j['contactPhone'],
    checkInStatus: j['checkInStatus'] ?? false,
  );
}
