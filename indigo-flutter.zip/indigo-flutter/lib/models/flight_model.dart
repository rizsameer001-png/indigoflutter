// lib/models/flight_model.dart

class Airport {
  final String code;
  final String city;
  final String name;
  final String country;
  final bool popular;

  Airport({
    required this.code,
    required this.city,
    required this.name,
    required this.country,
    this.popular = false,
  });

  factory Airport.fromJson(Map<String, dynamic> j) => Airport(
    code: j['code'] ?? '',
    city: j['city'] ?? '',
    name: j['name'] ?? '',
    country: j['country'] ?? '',
    popular: j['popular'] ?? false,
  );
}

class FlightPrice {
  final double base;
  final double taxes;

  FlightPrice({required this.base, required this.taxes});

  double get total => base + taxes;

  factory FlightPrice.fromJson(Map<String, dynamic> j) => FlightPrice(
    base: (j['base'] ?? 0).toDouble(),
    taxes: (j['taxes'] ?? 0).toDouble(),
  );
}

class FlightEndpoint {
  final String code;
  final String city;
  final String airport;
  final String? terminal;

  FlightEndpoint({
    required this.code,
    required this.city,
    required this.airport,
    this.terminal,
  });

  factory FlightEndpoint.fromJson(Map<String, dynamic> j) => FlightEndpoint(
    code: j['code'] ?? '',
    city: j['city'] ?? '',
    airport: j['airport'] ?? '',
    terminal: j['terminal'],
  );
}

class Flight {
  final String id;
  final String flightNumber;
  final String airline;
  final String aircraft;
  final FlightEndpoint origin;
  final FlightEndpoint destination;
  final DateTime departureTime;
  final DateTime arrivalTime;
  final int duration;
  final int stops;
  final FlightPrice economyPrice;
  final FlightPrice businessPrice;
  final int economySeats;
  final int businessSeats;
  final String status;

  Flight({
    required this.id,
    required this.flightNumber,
    required this.airline,
    required this.aircraft,
    required this.origin,
    required this.destination,
    required this.departureTime,
    required this.arrivalTime,
    required this.duration,
    required this.stops,
    required this.economyPrice,
    required this.businessPrice,
    required this.economySeats,
    required this.businessSeats,
    required this.status,
  });

  String get formattedDuration {
    final h = duration ~/ 60;
    final m = duration % 60;
    return '${h}h ${m}m';
  }

  factory Flight.fromJson(Map<String, dynamic> j) => Flight(
    id: j['_id'] ?? '',
    flightNumber: j['flightNumber'] ?? '',
    airline: j['airline'] ?? 'IndiGo',
    aircraft: j['aircraft'] ?? 'Airbus A320',
    origin: FlightEndpoint.fromJson(j['origin'] ?? {}),
    destination: FlightEndpoint.fromJson(j['destination'] ?? {}),
    departureTime: DateTime.parse(j['departureTime']),
    arrivalTime: DateTime.parse(j['arrivalTime']),
    duration: j['duration'] ?? 0,
    stops: j['stops'] ?? 0,
    economyPrice: FlightPrice.fromJson(j['price']?['economy'] ?? {}),
    businessPrice: FlightPrice.fromJson(j['price']?['business'] ?? {}),
    economySeats: j['seats']?['available']?['economy'] ?? 0,
    businessSeats: j['seats']?['available']?['business'] ?? 0,
    status: j['status'] ?? 'Scheduled',
  );

  double priceFor(String cabinClass) =>
      cabinClass == 'Business' ? businessPrice.total : economyPrice.total;
}
