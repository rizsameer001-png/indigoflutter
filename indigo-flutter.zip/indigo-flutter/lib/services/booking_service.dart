// lib/services/booking_service.dart

import 'api_service.dart';
import '../config/api_config.dart';
import '../models/booking_model.dart';

class BookingService {
  // ─── Create booking ───────────────────────────────────────────────────────
  static Future<Map<String, dynamic>> createBooking({
    required String flightId,
    required List<Passenger> passengers,
    required String cabinClass,
    required String contactEmail,
    required String contactPhone,
    String? returnFlightId,
    Map<String, bool>? addons,
  }) async {
    return ApiService.post(
      ApiConfig.bookings,
      auth: true,
      body: {
        'flightId': flightId,
        if (returnFlightId != null) 'returnFlightId': returnFlightId,
        'passengers': passengers.map((p) => p.toJson()).toList(),
        'class': cabinClass,
        'contactEmail': contactEmail,
        'contactPhone': contactPhone,
        if (addons != null) 'addons': addons,
      },
    );
  }

  // ─── Confirm payment ──────────────────────────────────────────────────────
  static Future<Map<String, dynamic>> confirmPayment({
    required String bookingId,
    required String paymentMethod,
  }) async {
    final txnId = 'TXN${DateTime.now().millisecondsSinceEpoch}';
    return ApiService.post(
      ApiConfig.confirmPayment,
      body: {
        'bookingId': bookingId,
        'paymentMethod': paymentMethod,
        'transactionId': txnId,
      },
    );
  }

  // ─── Get booking by PNR ───────────────────────────────────────────────────
  static Future<Map<String, dynamic>> getBookingByPNR(String pnr) async {
    return ApiService.get('/bookings/pnr/$pnr');
  }

  // ─── My bookings ─────────────────────────────────────────────────────────
  static Future<List<Booking>> getMyBookings() async {
    final data = await ApiService.get(ApiConfig.myBookings, auth: true);
    if (data['success'] == true) {
      return (data['bookings'] as List? ?? [])
          .map((b) => Booking.fromJson(b))
          .toList();
    }
    return [];
  }

  // ─── Cancel booking ───────────────────────────────────────────────────────
  static Future<Map<String, dynamic>> cancelBooking(String bookingId) async {
    return ApiService.put(
      '/bookings/$bookingId/cancel',
      body: {'reason': 'User requested'},
      auth: true,
    );
  }

  // ─── Web check-in ────────────────────────────────────────────────────────
  static Future<Map<String, dynamic>> webCheckIn({
    required String pnr,
    required String lastName,
  }) async {
    return ApiService.post(
      ApiConfig.checkIn,
      body: {'pnr': pnr, 'lastName': lastName},
    );
  }

  // ─── Validate promo code ─────────────────────────────────────────────────
  static Future<Map<String, dynamic>> validatePromo({
    required String code,
    required double amount,
  }) async {
    return ApiService.post(
      ApiConfig.validatePromo,
      body: {'code': code, 'amount': amount},
    );
  }
}
