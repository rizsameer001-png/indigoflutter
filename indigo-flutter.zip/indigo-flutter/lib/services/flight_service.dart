// lib/services/flight_service.dart

import 'api_service.dart';
import '../config/api_config.dart';
import '../models/flight_model.dart';

class FlightService {
  // ─── Search flights ───────────────────────────────────────────────────────
  static Future<Map<String, dynamic>> searchFlights({
    required String from,
    required String to,
    required String date,
    String? returnDate,
    int passengers = 1,
    String cabinClass = 'Economy',
    String tripType = 'One Way',
  }) async {
    final params = {
      'from': from,
      'to': to,
      'date': date,
      'passengers': passengers.toString(),
      'class': cabinClass,
      'tripType': tripType,
      if (returnDate != null) 'returnDate': returnDate,
    };
    final data = await ApiService.get(ApiConfig.flightSearch, params: params);
    if (data['success'] == true) {
      final outList = (data['outbound'] as List? ?? [])
          .map((f) => Flight.fromJson(f))
          .toList();
      final retList = (data['return'] as List? ?? [])
          .map((f) => Flight.fromJson(f))
          .toList();
      return {'success': true, 'outbound': outList, 'return': retList};
    }
    return data;
  }

  // ─── Get airports ────────────────────────────────────────────────────────
  static Future<List<Airport>> getAirports({
    String? search,
    bool popular = false,
  }) async {
    final params = <String, String>{};
    if (search != null && search.isNotEmpty) params['search'] = search;
    if (popular) params['popular'] = 'true';

    final data = await ApiService.get(ApiConfig.airports, params: params);
    if (data['success'] == true) {
      return (data['airports'] as List? ?? [])
          .map((a) => Airport.fromJson(a))
          .toList();
    }
    return [];
  }

  // ─── Flight status ───────────────────────────────────────────────────────
  static Future<Map<String, dynamic>> getFlightStatus({
    required String flightNumber,
    String? date,
  }) async {
    final params = {'flightNumber': flightNumber};
    if (date != null) params['date'] = date;
    return ApiService.get(ApiConfig.flightStatus, params: params);
  }

  // ─── Fare calendar (7 days) ───────────────────────────────────────────────
  static Future<List<Map<String, dynamic>>> getFareCalendar(
    String from,
    String to,
  ) async {
    final data = await ApiService.get(
      ApiConfig.fareCalendar,
      params: {'from': from, 'to': to},
    );
    if (data['success'] == true) {
      return List<Map<String, dynamic>>.from(data['calendar'] ?? []);
    }
    return [];
  }
}
