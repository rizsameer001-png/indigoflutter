// lib/services/api_service.dart

import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../config/api_config.dart';

class ApiService {
  static Future<String?> _getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('token');
  }

  static Future<Map<String, String>> _headers({bool auth = false}) async {
    final headers = <String, String>{'Content-Type': 'application/json'};
    if (auth) {
      final token = await _getToken();
      if (token != null) headers['Authorization'] = 'Bearer $token';
    }
    return headers;
  }

  // ─── GET ─────────────────────────────────────────────────────────────────
  static Future<Map<String, dynamic>> get(
    String path, {
    Map<String, String>? params,
    bool auth = false,
  }) async {
    try {
      final uri = Uri.parse('${ApiConfig.baseUrl}$path')
          .replace(queryParameters: params);
      final res = await http
          .get(uri, headers: await _headers(auth: auth))
          .timeout(const Duration(seconds: 15));
      return _handle(res);
    } catch (e) {
      return {'success': false, 'message': e.toString()};
    }
  }

  // ─── POST ────────────────────────────────────────────────────────────────
  static Future<Map<String, dynamic>> post(
    String path, {
    required Map<String, dynamic> body,
    bool auth = false,
  }) async {
    try {
      final res = await http
          .post(
            Uri.parse('${ApiConfig.baseUrl}$path'),
            headers: await _headers(auth: auth),
            body: jsonEncode(body),
          )
          .timeout(const Duration(seconds: 15));
      return _handle(res);
    } catch (e) {
      return {'success': false, 'message': e.toString()};
    }
  }

  // ─── PUT ─────────────────────────────────────────────────────────────────
  static Future<Map<String, dynamic>> put(
    String path, {
    required Map<String, dynamic> body,
    bool auth = true,
  }) async {
    try {
      final res = await http
          .put(
            Uri.parse('${ApiConfig.baseUrl}$path'),
            headers: await _headers(auth: auth),
            body: jsonEncode(body),
          )
          .timeout(const Duration(seconds: 15));
      return _handle(res);
    } catch (e) {
      return {'success': false, 'message': e.toString()};
    }
  }

  // ─── Handler ─────────────────────────────────────────────────────────────
  static Map<String, dynamic> _handle(http.Response res) {
    try {
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      if (res.statusCode >= 200 && res.statusCode < 300) return data;
      return {
        'success': false,
        'message': data['message'] ?? 'Request failed (${res.statusCode})',
      };
    } catch (_) {
      return {'success': false, 'message': 'Invalid server response'};
    }
  }
}
