// lib/services/auth_service.dart

import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'api_service.dart';
import '../config/api_config.dart';
import '../models/booking_model.dart';

class AuthService {
  // ─── Login ───────────────────────────────────────────────────────────────
  static Future<Map<String, dynamic>> login(String email, String password) async {
    final data = await ApiService.post(ApiConfig.login, body: {
      'email': email,
      'password': password,
    });
    if (data['success'] == true) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('token', data['token']);
      await prefs.setString('user', jsonEncode(data['user']));
    }
    return data;
  }

  // ─── Register ────────────────────────────────────────────────────────────
  static Future<Map<String, dynamic>> register({
    required String firstName,
    required String lastName,
    required String email,
    required String password,
    String? phone,
  }) async {
    final data = await ApiService.post(ApiConfig.register, body: {
      'firstName': firstName,
      'lastName': lastName,
      'email': email,
      'password': password,
      if (phone != null && phone.isNotEmpty) 'phone': phone,
    });
    if (data['success'] == true) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('token', data['token']);
      await prefs.setString('user', jsonEncode(data['user']));
    }
    return data;
  }

  // ─── Get stored user ─────────────────────────────────────────────────────
  static Future<Map<String, dynamic>?> getCachedUser() async {
    final prefs = await SharedPreferences.getInstance();
    final str = prefs.getString('user');
    if (str == null) return null;
    return jsonDecode(str) as Map<String, dynamic>;
  }

  static Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('token');
  }

  static Future<bool> isLoggedIn() async {
    final token = await getToken();
    return token != null && token.isNotEmpty;
  }

  // ─── Refresh profile from server ─────────────────────────────────────────
  static Future<Map<String, dynamic>> getMe() async {
    final data = await ApiService.get(ApiConfig.me, auth: true);
    if (data['success'] == true && data['user'] != null) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('user', jsonEncode(data['user']));
    }
    return data;
  }

  // ─── Update profile ──────────────────────────────────────────────────────
  static Future<Map<String, dynamic>> updateProfile(Map<String, dynamic> body) async {
    final data = await ApiService.put(ApiConfig.profile, body: body, auth: true);
    if (data['success'] == true && data['user'] != null) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('user', jsonEncode(data['user']));
    }
    return data;
  }

  // ─── Logout ──────────────────────────────────────────────────────────────
  static Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('token');
    await prefs.remove('user');
  }
}
