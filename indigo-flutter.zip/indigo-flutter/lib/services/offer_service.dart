// lib/services/offer_service.dart

import 'api_service.dart';
import '../config/api_config.dart';

class OfferService {
  static Future<List<Map<String, dynamic>>> getOffers() async {
    final data = await ApiService.get(ApiConfig.offers);
    if (data['success'] == true) {
      return List<Map<String, dynamic>>.from(data['offers'] ?? []);
    }
    return [];
  }
}
