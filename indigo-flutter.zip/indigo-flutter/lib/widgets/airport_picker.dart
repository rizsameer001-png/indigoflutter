// lib/widgets/airport_picker.dart

import 'package:flutter/material.dart';
import '../config/app_theme.dart';
import '../models/flight_model.dart';
import '../services/flight_service.dart';

class AirportPicker extends StatefulWidget {
  const AirportPicker({super.key});
  @override
  State<AirportPicker> createState() => _AirportPickerState();
}

class _AirportPickerState extends State<AirportPicker> {
  List<Airport> _airports = [];
  List<Airport> _filtered = [];
  final _ctrl = TextEditingController();
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final list = await FlightService.getAirports(popular: true);
    if (!mounted) return;
    setState(() { _airports = list; _filtered = list; _loading = false; });
  }

  void _filter(String q) {
    setState(() {
      _filtered = q.isEmpty
          ? _airports
          : _airports.where((a) =>
              a.code.toLowerCase().contains(q.toLowerCase()) ||
              a.city.toLowerCase().contains(q.toLowerCase()) ||
              a.name.toLowerCase().contains(q.toLowerCase())
            ).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.85,
      builder: (_, sc) => Column(children: [
        // Handle
        Container(
          margin: const EdgeInsets.symmetric(vertical: 8),
          width: 40, height: 4,
          decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(2)),
        ),
        const Text('Select Airport', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        Padding(
          padding: const EdgeInsets.all(12),
          child: TextField(
            controller: _ctrl,
            onChanged: _filter,
            autofocus: true,
            decoration: const InputDecoration(
              hintText: 'Search city or airport code...',
              prefixIcon: Icon(Icons.search),
            ),
          ),
        ),
        Expanded(
          child: _loading
              ? const Center(child: CircularProgressIndicator())
              : ListView.builder(
                  controller: sc,
                  itemCount: _filtered.length,
                  itemBuilder: (_, i) {
                    final a = _filtered[i];
                    return ListTile(
                      leading: Container(
                        width: 44, height: 44,
                        decoration: BoxDecoration(
                          color: AppTheme.primary.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        alignment: Alignment.center,
                        child: Text(a.code, style: const TextStyle(color: AppTheme.primary, fontWeight: FontWeight.w800, fontSize: 13)),
                      ),
                      title: Text(a.city, style: const TextStyle(fontWeight: FontWeight.w600)),
                      subtitle: Text(a.name, style: const TextStyle(fontSize: 12)),
                      trailing: a.popular
                          ? Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                              decoration: BoxDecoration(color: AppTheme.gold.withOpacity(0.2), borderRadius: BorderRadius.circular(10)),
                              child: const Text('Popular', style: TextStyle(fontSize: 10, color: Color(0xFF856404), fontWeight: FontWeight.w600)),
                            )
                          : null,
                      onTap: () => Navigator.pop(context, a),
                    );
                  },
                ),
        ),
      ]),
    );
  }
}
