// lib/widgets/flight_card_widget.dart

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../config/app_theme.dart';
import '../models/flight_model.dart';

class FlightCardWidget extends StatelessWidget {
  final Flight flight;
  final String cabinClass;
  final int passengers;
  final bool selected;
  final VoidCallback onSelect;

  const FlightCardWidget({
    super.key,
    required this.flight,
    required this.cabinClass,
    required this.passengers,
    required this.onSelect,
    this.selected = false,
  });

  @override
  Widget build(BuildContext context) {
    final price = flight.priceFor(cabinClass) * passengers;
    final fmt = NumberFormat('#,##0', 'en_IN');

    return GestureDetector(
      onTap: onSelect,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        margin: const EdgeInsets.symmetric(vertical: 6),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFFF0F6FF) : Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: selected ? AppTheme.primary : AppTheme.border,
            width: selected ? 2 : 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: selected
                  ? AppTheme.primary.withOpacity(0.1)
                  : Colors.black.withOpacity(0.04),
              blurRadius: 8, offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(children: [
            Row(children: [
              // Airline logo
              Container(
                width: 40, height: 40,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [AppTheme.primary, Color(0xFF1A73E8)],
                  ),
                  borderRadius: BorderRadius.circular(10),
                ),
                alignment: Alignment.center,
                child: const Text('6E', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 14)),
              ),
              const SizedBox(width: 10),
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(flight.flightNumber, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
                Text(flight.aircraft, style: const TextStyle(fontSize: 11, color: AppTheme.textGray)),
              ]),
              const Spacer(),
              _statusChip(flight.status),
            ]),

            const SizedBox(height: 14),

            // Route
            Row(children: [
              _timeBlock(
                DateFormat('HH:mm').format(flight.departureTime),
                flight.origin.code,
                flight.origin.city,
              ),
              Expanded(
                child: Column(children: [
                  Text(flight.formattedDuration, style: const TextStyle(fontSize: 11, color: AppTheme.textGray)),
                  const SizedBox(height: 4),
                  Stack(alignment: Alignment.centerRight, children: [
                    Container(height: 1.5, color: AppTheme.border),
                    const Icon(Icons.flight, color: AppTheme.primary, size: 16),
                  ]),
                  const SizedBox(height: 4),
                  Text(
                    flight.stops == 0 ? 'Non-stop' : '${flight.stops} stop',
                    style: TextStyle(fontSize: 11, color: flight.stops == 0 ? AppTheme.success : Colors.orange, fontWeight: FontWeight.w500),
                  ),
                ]),
              ),
              _timeBlock(
                DateFormat('HH:mm').format(flight.arrivalTime),
                flight.destination.code,
                flight.destination.city,
                rightAlign: true,
              ),
            ]),

            const Divider(height: 18),

            Row(children: [
              const Icon(Icons.luggage_outlined, size: 14, color: AppTheme.textGray),
              const SizedBox(width: 4),
              Text('15kg check-in', style: const TextStyle(fontSize: 12, color: AppTheme.textGray)),
              const Spacer(),
              Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                Text('₹${fmt.format(price)}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: AppTheme.primary)),
                Text('all-in · $passengers pax', style: const TextStyle(fontSize: 11, color: AppTheme.textGray)),
              ]),
              const SizedBox(width: 10),
              ElevatedButton(
                onPressed: onSelect,
                style: ElevatedButton.styleFrom(
                  backgroundColor: selected ? AppTheme.success : AppTheme.primary,
                  minimumSize: const Size(70, 36),
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
                child: Text(selected ? '✓ Selected' : 'Select', style: const TextStyle(fontSize: 13)),
              ),
            ]),
          ]),
        ),
      ),
    );
  }

  Widget _timeBlock(String time, String code, String city, {bool rightAlign = false}) {
    return SizedBox(
      width: 70,
      child: Column(
        crossAxisAlignment: rightAlign ? CrossAxisAlignment.end : CrossAxisAlignment.start,
        children: [
          Text(time, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
          Text(code, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppTheme.primary)),
          Text(city, style: const TextStyle(fontSize: 10, color: AppTheme.textGray)),
        ],
      ),
    );
  }

  Widget _statusChip(String status) {
    final colors = {
      'On Time': const Color(0xFF22C55E),
      'Scheduled': AppTheme.primary,
      'Delayed': Colors.orange,
      'Cancelled': AppTheme.error,
      'Boarding': Colors.blue,
    };
    final c = colors[status] ?? AppTheme.textGray;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(color: c.withOpacity(0.1), borderRadius: BorderRadius.circular(6)),
      child: Text(status, style: TextStyle(color: c, fontSize: 11, fontWeight: FontWeight.w600)),
    );
  }
}
