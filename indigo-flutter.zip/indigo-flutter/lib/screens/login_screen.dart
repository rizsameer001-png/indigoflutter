// lib/screens/login_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../config/app_theme.dart';
import '../providers/auth_provider.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override State<LoginScreen> createState() => _LoginScreenState();
}
class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _emailCtrl = TextEditingController();
  final _passCtrl  = TextEditingController();
  bool _obscure = true;

  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) return;
    final ok = await context.read<AuthProvider>().login(_emailCtrl.text.trim(), _passCtrl.text);
    if (!mounted) return;
    if (ok) { Navigator.pop(context); }
    else { ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(context.read<AuthProvider>().error ?? 'Login failed'))); }
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    return Scaffold(
      appBar: AppBar(title: const Text('Sign In')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Form(key: _formKey, child: Column(children: [
          const SizedBox(height: 20),
          const Icon(Icons.flight, size: 60, color: AppTheme.primary),
          const SizedBox(height: 8),
          const Text('Welcome Back', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 32),
          TextFormField(controller: _emailCtrl, keyboardType: TextInputType.emailAddress,
            decoration: const InputDecoration(labelText: 'Email', prefixIcon: Icon(Icons.email_outlined)),
            validator: (v) => v?.contains('@') == true ? null : 'Enter valid email'),
          const SizedBox(height: 14),
          TextFormField(controller: _passCtrl, obscureText: _obscure,
            decoration: InputDecoration(labelText: 'Password', prefixIcon: const Icon(Icons.lock_outlined),
              suffixIcon: IconButton(icon: Icon(_obscure ? Icons.visibility : Icons.visibility_off), onPressed: () => setState(() => _obscure = !_obscure))),
            validator: (v) => (v?.length ?? 0) >= 6 ? null : 'Min 6 characters'),
          const SizedBox(height: 24),
          ElevatedButton(onPressed: auth.loading ? null : _login,
            child: auth.loading ? const SizedBox(height:20,width:20,child:CircularProgressIndicator(color:Colors.white,strokeWidth:2)) : const Text('Sign In')),
          const SizedBox(height: 16),
          TextButton(onPressed: () => Navigator.pushReplacementNamed(context, '/register'),
            child: const Text("Don't have an account? Register")),
        ])),
      ),
    );
  }
}

// lib/screens/register_screen.dart
class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});
  @override State<RegisterScreen> createState() => _RegisterScreenState();
}
class _RegisterScreenState extends State<RegisterScreen> {
  final _formKey = GlobalKey<FormState>();
  final _fn = TextEditingController(), _ln = TextEditingController(),
        _em = TextEditingController(), _ph = TextEditingController(),
        _pw = TextEditingController();

  Future<void> _register() async {
    if (!_formKey.currentState!.validate()) return;
    final ok = await context.read<AuthProvider>().register(
      firstName: _fn.text.trim(), lastName: _ln.text.trim(),
      email: _em.text.trim(), password: _pw.text, phone: _ph.text.trim(),
    );
    if (!mounted) return;
    if (ok) { Navigator.pop(context); }
    else { ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(context.read<AuthProvider>().error ?? 'Registration failed'))); }
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    return Scaffold(
      appBar: AppBar(title: const Text('Create Account')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Form(key: _formKey, child: ListView(children: [
          const Icon(Icons.flight, size: 50, color: AppTheme.primary),
          const SizedBox(height: 8),
          const Text('Join IndiGo', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
          const SizedBox(height: 24),
          Row(children: [
            Expanded(child: TextFormField(controller: _fn, decoration: const InputDecoration(labelText: 'First Name'), validator: (v) => v?.isEmpty == true ? 'Required' : null)),
            const SizedBox(width: 12),
            Expanded(child: TextFormField(controller: _ln, decoration: const InputDecoration(labelText: 'Last Name'), validator: (v) => v?.isEmpty == true ? 'Required' : null)),
          ]),
          const SizedBox(height: 12),
          TextFormField(controller: _em, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Email'), validator: (v) => v?.contains('@') == true ? null : 'Valid email required'),
          const SizedBox(height: 12),
          TextFormField(controller: _ph, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Phone (optional)')),
          const SizedBox(height: 12),
          TextFormField(controller: _pw, obscureText: true, decoration: const InputDecoration(labelText: 'Password'), validator: (v) => (v?.length ?? 0) >= 6 ? null : 'Min 6 characters'),
          const SizedBox(height: 24),
          ElevatedButton(onPressed: auth.loading ? null : _register,
            child: auth.loading ? const SizedBox(height:20,width:20,child:CircularProgressIndicator(color:Colors.white,strokeWidth:2)) : const Text('Create Account')),
          TextButton(onPressed: () => Navigator.pushReplacementNamed(context, '/login'), child: const Text('Already have an account? Sign In')),
        ])),
      ),
    );
  }
}

// lib/screens/profile_screen.dart
class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    if (!auth.isLoggedIn) {
      return Scaffold(
        appBar: AppBar(title: const Text('Profile')),
        body: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.person, size: 60, color: AppTheme.textGray),
          const SizedBox(height: 16),
          const Text('Not logged in', style: TextStyle(fontSize: 18)),
          const SizedBox(height: 16),
          ElevatedButton(onPressed: () => Navigator.pushNamed(context, '/login'), child: const Text('Sign In')),
        ])),
      );
    }
    final user = auth.user!;
    return Scaffold(
      appBar: AppBar(title: const Text('My Profile')),
      body: ListView(children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: const BoxDecoration(gradient: LinearGradient(colors: [AppTheme.primary, Color(0xFF1A73E8)])),
          child: Row(children: [
            CircleAvatar(radius: 34, backgroundColor: Colors.white30, child: Text(user['firstName'][0].toUpperCase(), style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold))),
            const SizedBox(width: 14),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('${user['firstName']} ${user['lastName']}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18)),
              Text(user['email'] ?? '', style: const TextStyle(color: Colors.white70, fontSize: 12)),
            ])),
            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              const Text('Points', style: TextStyle(color: Colors.white70, fontSize: 11)),
              Text('${user['loyaltyPoints'] ?? 0}', style: const TextStyle(color: AppTheme.gold, fontWeight: FontWeight.w800, fontSize: 24)),
              Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2), decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(10)),
                child: Text(user['tier'] ?? 'Blue', style: const TextStyle(color: Colors.white, fontSize: 11))),
            ]),
          ]),
        ),
        ListTile(leading: const Icon(Icons.confirmation_number), title: const Text('My Bookings'), trailing: const Icon(Icons.chevron_right), onTap: () => Navigator.pushNamed(context, '/my-bookings')),
        ListTile(leading: const Icon(Icons.check_circle_outline), title: const Text('Web Check-in'), trailing: const Icon(Icons.chevron_right), onTap: () => Navigator.pushNamed(context, '/check-in')),
        ListTile(leading: const Icon(Icons.local_offer), title: const Text('Offers'), trailing: const Icon(Icons.chevron_right), onTap: () => Navigator.pushNamed(context, '/offers')),
        const Divider(),
        ListTile(leading: const Icon(Icons.logout, color: AppTheme.error), title: const Text('Logout', style: TextStyle(color: AppTheme.error)),
          onTap: () async { await auth.logout(); Navigator.pushNamedAndRemoveUntil(context, '/home', (_)=>false); }),
      ]),
    );
  }
}
