// lib/screens/home_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../config/app_theme.dart';
import '../providers/auth_provider.dart';
import '../providers/booking_provider.dart';
import '../services/flight_service.dart';
import '../services/offer_service.dart';
import '../models/flight_model.dart';
import '../widgets/airport_picker.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String _tripType = 'One Way';
  Airport? _from;
  Airport? _to;
  DateTime _date = DateTime.now().add(const Duration(days: 2));
  DateTime? _returnDate;
  int _passengers = 1;
  String _cabinClass = 'Economy';
  List<Map<String, dynamic>> _offers = [];

  @override
  void initState() {
    super.initState();
    _loadOffers();
  }

  Future<void> _loadOffers() async {
    final offers = await OfferService.getOffers();
    if (mounted) setState(() => _offers = offers.take(2).toList());
  }

  void _swapCities() {
    setState(() { final tmp = _from; _from = _to; _to = tmp; });
  }

  Future<void> _pickDate(bool isReturn) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: isReturn ? (_returnDate ?? _date.add(const Duration(days: 7))) : _date,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365)),
      builder: (ctx, child) => Theme(
        data: Theme.of(ctx).copyWith(
          colorScheme: const ColorScheme.light(primary: AppTheme.primary),
        ),
        child: child!,
      ),
    );
    if (picked == null) return;
    setState(() { isReturn ? _returnDate = picked : _date = picked; });
  }

  void _search() {
    if (_from == null || _to == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select origin and destination')),
      );
      return;
    }
    final bp = context.read<BookingProvider>();
    bp.setSearch(
      f: _from!.code, t: _to!.code,
      fc: _from!.city, tc: _to!.city,
      d: DateFormat('yyyy-MM-dd').format(_date),
      rd: _returnDate != null ? DateFormat('yyyy-MM-dd').format(_returnDate!) : null,
      pax: _passengers, cls: _cabinClass, trip: _tripType,
    );
    Navigator.pushNamed(context, '/search-results');
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    return Scaffold(
      body: CustomScrollView(
        slivers: [
          // ─── Header ───────────────────────────────────────────────────
          SliverAppBar(
            expandedHeight: 200,
            pinned: true,
            automaticallyImplyLeading: false,
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Color(0xFF0D1B2E), AppTheme.primary],
                  ),
                ),
                padding: const EdgeInsets.fromLTRB(20, 50, 20, 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(children: [
                      const Icon(Icons.flight, color: AppTheme.gold, size: 26),
                      const SizedBox(width: 8),
                      const Text('IndiGo', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900)),
                      const Spacer(),
                      if (auth.isLoggedIn)
                        GestureDetector(
                          onTap: () => Navigator.pushNamed(context, '/profile'),
                          child: CircleAvatar(
                            backgroundColor: Colors.white24,
                            child: Text(
                              auth.user!['firstName'][0].toUpperCase(),
                              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                            ),
                          ),
                        )
                      else
                        TextButton(
                          onPressed: () => Navigator.pushNamed(context, '/login'),
                          child: const Text('Login', style: TextStyle(color: Colors.white)),
                        ),
                    ]),
                    const SizedBox(height: 14),
                    RichText(text: const TextSpan(children: [
                      TextSpan(text: 'Fly Smart, ', style: TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.bold)),
                      TextSpan(text: 'Fly IndiGo ✈️', style: TextStyle(color: AppTheme.gold, fontSize: 26, fontWeight: FontWeight.bold)),
                    ])),
                  ],
                ),
              ),
            ),
          ),

          // ─── Search Card ──────────────────────────────────────────────
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Card(
                elevation: 3,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(children: [
                    // Trip type tabs
                    Row(children: ['One Way', 'Round Trip'].map((t) =>
                      Expanded(child: GestureDetector(
                        onTap: () => setState(() => _tripType = t),
                        child: Container(
                          margin: const EdgeInsets.symmetric(horizontal: 4),
                          padding: const EdgeInsets.symmetric(vertical: 8),
                          decoration: BoxDecoration(
                            color: _tripType == t ? AppTheme.primary : Colors.transparent,
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: _tripType == t ? AppTheme.primary : AppTheme.border),
                          ),
                          alignment: Alignment.center,
                          child: Text(t, style: TextStyle(
                            color: _tripType == t ? Colors.white : AppTheme.textGray,
                            fontWeight: FontWeight.w600, fontSize: 13,
                          )),
                        ),
                      ))
                    ).toList()),

                    const SizedBox(height: 14),

                    // From / To
                    Row(children: [
                      Expanded(child: _airportField('FROM', _from, () async {
                        final a = await showModalBottomSheet<Airport>(
                          context: context,
                          isScrollControlled: true,
                          builder: (_) => const AirportPicker(),
                        );
                        if (a != null) setState(() => _from = a);
                      })),
                      IconButton(
                        onPressed: _swapCities,
                        icon: const Icon(Icons.swap_horiz, color: AppTheme.primary),
                      ),
                      Expanded(child: _airportField('TO', _to, () async {
                        final a = await showModalBottomSheet<Airport>(
                          context: context,
                          isScrollControlled: true,
                          builder: (_) => const AirportPicker(),
                        );
                        if (a != null) setState(() => _to = a);
                      })),
                    ]),

                    const SizedBox(height: 10),

                    // Dates
                    Row(children: [
                      Expanded(child: _dateField('DEPART', _date, () => _pickDate(false))),
                      const SizedBox(width: 10),
                      if (_tripType == 'Round Trip')
                        Expanded(child: _dateField('RETURN', _returnDate, () => _pickDate(true))),
                    ]),

                    const SizedBox(height: 10),

                    // Pax + Class
                    Row(children: [
                      Expanded(child: _dropdownField<int>(
                        'PASSENGERS',
                        _passengers,
                        List.generate(9, (i) => i + 1),
                        (v) => setState(() => _passengers = v!),
                        (v) => '$v Adult${v! > 1 ? 's' : ''}',
                      )),
                      const SizedBox(width: 10),
                      Expanded(child: _dropdownField<String>(
                        'CLASS',
                        _cabinClass,
                        ['Economy', 'Business'],
                        (v) => setState(() => _cabinClass = v!),
                        (v) => v!,
                      )),
                    ]),

                    const SizedBox(height: 14),
                    ElevatedButton.icon(
                      onPressed: _search,
                      icon: const Icon(Icons.search),
                      label: const Text('Search Flights'),
                    ),
                  ]),
                ),
              ),
            ),
          ),

          // ─── Quick actions ────────────────────────────────────────────
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _quickBtn(Icons.check_circle_outline, 'Check-in', '/check-in', Colors.green),
                  _quickBtn(Icons.edit_note, 'Manage', '/manage-booking', Colors.blue),
                  _quickBtn(Icons.flight_takeoff, 'Status', '/flight-status', Colors.orange),
                  _quickBtn(Icons.local_offer, 'Offers', '/offers', Colors.purple),
                ],
              ),
            ),
          ),

          const SliverToBoxAdapter(child: SizedBox(height: 16)),

          // ─── Offers ───────────────────────────────────────────────────
          if (_offers.isNotEmpty) ...[
            const SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.fromLTRB(16, 0, 16, 10),
                child: Text('🏷️ Current Offers', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              ),
            ),
            SliverList(
              delegate: SliverChildBuilderDelegate(
                (ctx, i) => _offerCard(_offers[i]),
                childCount: _offers.length,
              ),
            ),
          ],

          const SliverToBoxAdapter(child: SizedBox(height: 80)),
        ],
      ),
      bottomNavigationBar: _bottomNav(context, 0),
    );
  }

  Widget _airportField(String label, Airport? airport, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          border: Border.all(color: AppTheme.border),
          borderRadius: BorderRadius.circular(10),
          color: Colors.white,
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: AppTheme.textGray, letterSpacing: 0.5)),
          const SizedBox(height: 2),
          Text(
            airport?.code ?? 'Select',
            style: TextStyle(
              fontSize: 20, fontWeight: FontWeight.w800,
              color: airport != null ? AppTheme.primary : AppTheme.textGray,
            ),
          ),
          Text(airport?.city ?? 'City', style: const TextStyle(fontSize: 12, color: AppTheme.textGray)),
        ]),
      ),
    );
  }

  Widget _dateField(String label, DateTime? date, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          border: Border.all(color: AppTheme.border),
          borderRadius: BorderRadius.circular(10),
          color: Colors.white,
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: AppTheme.textGray, letterSpacing: 0.5)),
          const SizedBox(height: 2),
          Text(
            date != null ? DateFormat('dd MMM').format(date) : 'Select',
            style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
          ),
          Text(date != null ? DateFormat('EEE, yyyy').format(date) : '', style: const TextStyle(fontSize: 11, color: AppTheme.textGray)),
        ]),
      ),
    );
  }

  Widget _dropdownField<T>(String label, T value, List<T> items, ValueChanged<T?> onChanged, String Function(T?) display) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        border: Border.all(color: AppTheme.border),
        borderRadius: BorderRadius.circular(10),
        color: Colors.white,
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: AppTheme.textGray, letterSpacing: 0.5)),
        DropdownButton<T>(
          value: value,
          items: items.map((i) => DropdownMenuItem<T>(value: i, child: Text(display(i), style: const TextStyle(fontWeight: FontWeight.w600)))).toList(),
          onChanged: onChanged,
          underline: const SizedBox(),
          isDense: true,
          isExpanded: true,
        ),
      ]),
    );
  }

  Widget _quickBtn(IconData icon, String label, String route, Color color) {
    return GestureDetector(
      onTap: () => Navigator.pushNamed(context, route),
      child: Column(children: [
        Container(
          width: 52, height: 52,
          decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(14)),
          child: Icon(icon, color: color, size: 24),
        ),
        const SizedBox(height: 6),
        Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500)),
      ]),
    );
  }

  Widget _offerCard(Map<String, dynamic> offer) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: const Border(left: BorderSide(color: AppTheme.primary, width: 4)),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 6, offset: const Offset(0, 2))],
        ),
        child: Row(children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(offer['title'] ?? '', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
            const SizedBox(height: 4),
            Text(offer['description'] ?? '', style: const TextStyle(fontSize: 12, color: AppTheme.textGray)),
          ])),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(color: AppTheme.primary.withOpacity(0.1), borderRadius: BorderRadius.circular(6)),
            child: Text(offer['code'] ?? '', style: const TextStyle(color: AppTheme.primary, fontWeight: FontWeight.w800, fontSize: 13, letterSpacing: 1)),
          ),
        ]),
      ),
    );
  }
}

Widget _bottomNav(BuildContext ctx, int index) {
  return BottomNavigationBar(
    currentIndex: index,
    selectedItemColor: AppTheme.primary,
    unselectedItemColor: AppTheme.textGray,
    type: BottomNavigationBarType.fixed,
    items: const [
      BottomNavigationBarItem(icon: Icon(Icons.home_outlined), activeIcon: Icon(Icons.home), label: 'Home'),
      BottomNavigationBarItem(icon: Icon(Icons.confirmation_number_outlined), activeIcon: Icon(Icons.confirmation_number), label: 'Bookings'),
      BottomNavigationBarItem(icon: Icon(Icons.local_offer_outlined), activeIcon: Icon(Icons.local_offer), label: 'Offers'),
      BottomNavigationBarItem(icon: Icon(Icons.person_outline), activeIcon: Icon(Icons.person), label: 'Profile'),
    ],
    onTap: (i) {
      const routes = ['/home', '/my-bookings', '/offers', '/profile'];
      if (i != index) Navigator.pushReplacementNamed(ctx, routes[i]);
    },
  );
}
