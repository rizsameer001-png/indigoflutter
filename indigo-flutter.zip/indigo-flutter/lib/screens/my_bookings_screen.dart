// lib/screens/my_bookings_screen.dart
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../config/app_theme.dart';
import '../models/booking_model.dart';
import '../services/booking_service.dart';

class MyBookingsScreen extends StatefulWidget {
  const MyBookingsScreen({super.key});
  @override State<MyBookingsScreen> createState() => _MyBookingsScreenState();
}
class _MyBookingsScreenState extends State<MyBookingsScreen> {
  List<Booking> _bookings = [];
  bool _loading = true;

  @override
  void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final data = await BookingService.getMyBookings();
    if (mounted) setState(() { _bookings = data; _loading = false; });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('My Bookings'), actions: [
      IconButton(icon: const Icon(Icons.refresh), onPressed: _load),
    ]),
    body: _loading ? const Center(child: CircularProgressIndicator()) :
      _bookings.isEmpty ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text('✈️', style: TextStyle(fontSize: 60)),
        const SizedBox(height: 16),
        const Text('No bookings yet', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('Your trips will appear here', style: TextStyle(color: AppTheme.textGray)),
        const SizedBox(height: 20),
        ElevatedButton.icon(
          onPressed: () => Navigator.pushNamedAndRemoveUntil(context, '/home', (_) => false),
          icon: const Icon(Icons.search), label: const Text('Search Flights'),
          style: ElevatedButton.styleFrom(minimumSize: const Size(200, 48)),
        ),
      ])) :
      ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _bookings.length,
        itemBuilder: (_, i) {
          final b = _bookings[i];
          final flight = b.outboundFlight;
          final statusColors = {'Confirmed': AppTheme.success, 'Cancelled': AppTheme.error, 'Pending': Colors.orange};
          final sc = statusColors[b.status] ?? AppTheme.textGray;
          return Card(
            margin: const EdgeInsets.only(bottom: 12),
            child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Text(b.pnr, style: const TextStyle(fontFamily: 'monospace', fontWeight: FontWeight.w900, fontSize: 20, color: AppTheme.primary, letterSpacing: 2)),
                Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(color: sc.withOpacity(0.1), borderRadius: BorderRadius.circular(20)),
                  child: Text(b.status, style: TextStyle(color: sc, fontWeight: FontWeight.bold, fontSize: 12))),
              ]),
              const SizedBox(height: 10),
              if (flight != null) Text(
                '${flight['origin']?['city'] ?? ''} → ${flight['destination']?['city'] ?? ''}',
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
              const SizedBox(height: 4),
              Text('${b.passengers.length} passenger${b.passengers.length > 1 ? 's' : ''} · ${b.cabinClass}',
                style: const TextStyle(color: AppTheme.textGray, fontSize: 13)),
              const Divider(height: 16),
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Text('Total Paid', style: const TextStyle(color: AppTheme.textGray)),
                Text('₹${NumberFormat('#,##0').format(b.pricing.total)}',
                  style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17, color: AppTheme.primary)),
              ]),
            ])),
          );
        },
      ),
  );
}
