// lib/screens/register_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../config/app_theme.dart';
import '../providers/auth_provider.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});
  @override State<RegisterScreen> createState() => _RegisterScreenState();
}
class _RegisterScreenState extends State<RegisterScreen> {
  final _formKey = GlobalKey<FormState>();
  final _fn = TextEditingController(), _ln = TextEditingController(),
        _em = TextEditingController(), _ph = TextEditingController(),
        _pw = TextEditingController();

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    final ok = await context.read<AuthProvider>().register(
      firstName: _fn.text.trim(), lastName: _ln.text.trim(),
      email: _em.text.trim(), password: _pw.text, phone: _ph.text.trim(),
    );
    if (!mounted) return;
    if (ok) { Navigator.pop(context); }
    else { ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(context.read<AuthProvider>().error ?? 'Registration failed'))); }
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    return Scaffold(
      appBar: AppBar(title: const Text('Create Account')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Form(key: _formKey, child: ListView(children: [
          const Icon(Icons.flight, size: 50, color: AppTheme.primary),
          const SizedBox(height: 8),
          const Text('Join IndiGo', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
          const SizedBox(height: 24),
          Row(children: [
            Expanded(child: TextFormField(controller: _fn, decoration: const InputDecoration(labelText: 'First Name'), validator: (v) => v?.isEmpty == true ? 'Required' : null)),
            const SizedBox(width: 12),
            Expanded(child: TextFormField(controller: _ln, decoration: const InputDecoration(labelText: 'Last Name'), validator: (v) => v?.isEmpty == true ? 'Required' : null)),
          ]),
          const SizedBox(height: 12),
          TextFormField(controller: _em, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Email'), validator: (v) => v?.contains('@') == true ? null : 'Valid email required'),
          const SizedBox(height: 12),
          TextFormField(controller: _ph, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Phone (optional)')),
          const SizedBox(height: 12),
          TextFormField(controller: _pw, obscureText: true, decoration: const InputDecoration(labelText: 'Password'), validator: (v) => (v?.length ?? 0) >= 6 ? null : 'Min 6 characters'),
          const SizedBox(height: 24),
          ElevatedButton(onPressed: auth.loading ? null : _submit,
            child: auth.loading ? const SizedBox(height:20,width:20,child:CircularProgressIndicator(color:Colors.white,strokeWidth:2)) : const Text('Create Account')),
          TextButton(onPressed: () => Navigator.pushReplacementNamed(context, '/login'), child: const Text('Already have an account? Sign In')),
        ])),
      ),
    );
  }
}
