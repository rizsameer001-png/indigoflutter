// lib/screens/search_results_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../config/app_theme.dart';
import '../providers/booking_provider.dart';
import '../services/flight_service.dart';
import '../models/flight_model.dart';
import '../widgets/flight_card_widget.dart';

class SearchResultsScreen extends StatefulWidget {
  const SearchResultsScreen({super.key});
  @override
  State<SearchResultsScreen> createState() => _SearchResultsScreenState();
}

class _SearchResultsScreenState extends State<SearchResultsScreen> {
  List<Flight> _outbound = [];
  List<Flight> _return = [];
  bool _loading = true;
  String _error = '';
  String _sortBy = 'price';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _search());
  }

  Future<void> _search() async {
    final bp = context.read<BookingProvider>();
    setState(() { _loading = true; _error = ''; });

    final result = await FlightService.searchFlights(
      from: bp.from, to: bp.to, date: bp.date,
      returnDate: bp.returnDate,
      passengers: bp.passengers, cabinClass: bp.cabinClass,
      tripType: bp.tripType,
    );

    if (!mounted) return;
    if (result['success'] == true) {
      setState(() {
        _outbound = (result['outbound'] as List<Flight>? ?? []);
        _return = (result['return'] as List<Flight>? ?? []);
        _loading = false;
      });
    } else {
      setState(() { _error = result['message'] ?? 'Failed to load flights'; _loading = false; });
    }
  }

  List<Flight> _sorted(List<Flight> flights) {
    final bp = context.read<BookingProvider>();
    final list = [...flights];
    switch (_sortBy) {
      case 'price': list.sort((a, b) => a.priceFor(bp.cabinClass).compareTo(b.priceFor(bp.cabinClass))); break;
      case 'duration': list.sort((a, b) => a.duration.compareTo(b.duration)); break;
      case 'departure': list.sort((a, b) => a.departureTime.compareTo(b.departureTime)); break;
    }
    return list;
  }

  @override
  Widget build(BuildContext context) {
    final bp = context.watch<BookingProvider>();

    return Scaffold(
      appBar: AppBar(
        title: Text('${bp.from} → ${bp.to}'),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.sort, color: Colors.white),
            onSelected: (v) => setState(() => _sortBy = v),
            itemBuilder: (_) => [
              const PopupMenuItem(value: 'price', child: Text('Sort by Price')),
              const PopupMenuItem(value: 'duration', child: Text('Sort by Duration')),
              const PopupMenuItem(value: 'departure', child: Text('Sort by Departure')),
            ],
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error.isNotEmpty
              ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Icon(Icons.flight_land, size: 60, color: AppTheme.textGray),
                  const SizedBox(height: 12),
                  Text(_error, style: const TextStyle(color: AppTheme.textGray)),
                  const SizedBox(height: 16),
                  ElevatedButton(onPressed: _search, child: const Text('Retry')),
                ]))
              : _outbound.isEmpty
                  ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                      const Text('✈️', style: TextStyle(fontSize: 60)),
                      const SizedBox(height: 12),
                      const Text('No flights found', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 8),
                      const Text('Try different dates', style: TextStyle(color: AppTheme.textGray)),
                    ]))
                  : ListView(
                      padding: const EdgeInsets.all(16),
                      children: [
                        if (bp.tripType == 'Round Trip')
                          const _SectionLabel(text: '➡ Outbound Flight', color: AppTheme.primary),
                        ..._sorted(_outbound).map((f) => FlightCardWidget(
                          flight: f,
                          cabinClass: bp.cabinClass,
                          passengers: bp.passengers,
                          selected: bp.selectedOutbound?.id == f.id,
                          onSelect: () {
                            bp.selectOutbound(f);
                            if (bp.tripType != 'Round Trip') {
                              Navigator.pushNamed(context, '/passengers');
                            }
                          },
                        )),
                        if (bp.tripType == 'Round Trip' && bp.selectedOutbound != null && _return.isNotEmpty) ...[
                          const SizedBox(height: 16),
                          const _SectionLabel(text: '↩ Return Flight', color: Colors.green),
                          ..._sorted(_return).map((f) => FlightCardWidget(
                            flight: f,
                            cabinClass: bp.cabinClass,
                            passengers: bp.passengers,
                            selected: bp.selectedReturn?.id == f.id,
                            onSelect: () => bp.selectReturn(f),
                          )),
                        ],
                        const SizedBox(height: 80),
                      ],
                    ),
      bottomNavigationBar: bp.selectedOutbound != null
          ? Container(
              padding: const EdgeInsets.all(16),
              decoration: const BoxDecoration(
                color: Colors.white,
                border: Border(top: BorderSide(color: AppTheme.border)),
              ),
              child: Row(children: [
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(bp.selectedOutbound!.flightNumber, style: const TextStyle(fontWeight: FontWeight.bold)),
                  Text('₹${bp.totalPrice.toStringAsFixed(0)}', style: const TextStyle(color: AppTheme.primary, fontWeight: FontWeight.w800, fontSize: 18)),
                ])),
                ElevatedButton(
                  onPressed: () {
                    if (bp.tripType == 'Round Trip' && bp.selectedReturn == null) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Please select return flight')),
                      );
                      return;
                    }
                    Navigator.pushNamed(context, '/passengers');
                  },
                  style: ElevatedButton.styleFrom(minimumSize: const Size(140, 48)),
                  child: const Text('Continue →'),
                ),
              ]),
            )
          : null,
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String text;
  final Color color;
  const _SectionLabel({required this.text, required this.color});
  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 10),
    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
    decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(8)),
    child: Text(text, style: TextStyle(color: color, fontWeight: FontWeight.w600, fontSize: 14)),
  );
}
