// lib/screens/profile_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../config/app_theme.dart';
import '../providers/auth_provider.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    if (!auth.isLoggedIn) {
      return Scaffold(
        appBar: AppBar(title: const Text('Profile')),
        body: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.person, size: 60, color: AppTheme.textGray),
          const SizedBox(height: 16),
          const Text('Not signed in', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('Sign in to access your profile', style: TextStyle(color: AppTheme.textGray)),
          const SizedBox(height: 20),
          ElevatedButton.icon(
            onPressed: () => Navigator.pushNamed(context, '/login'),
            icon: const Icon(Icons.login),
            label: const Text('Sign In'),
            style: ElevatedButton.styleFrom(minimumSize: const Size(200, 48)),
          ),
          TextButton(onPressed: () => Navigator.pushNamed(context, '/register'), child: const Text('Create an account')),
        ])),
      );
    }
    final user = auth.user!;
    return Scaffold(
      appBar: AppBar(title: const Text('My Profile'), actions: [
        IconButton(icon: const Icon(Icons.refresh), onPressed: auth.refreshUser),
      ]),
      body: ListView(children: [
        // Header card
        Container(
          padding: const EdgeInsets.fromLTRB(20, 24, 20, 24),
          decoration: const BoxDecoration(
            gradient: LinearGradient(colors: [Color(0xFF0D1B2E), AppTheme.primary]),
          ),
          child: Row(children: [
            CircleAvatar(
              radius: 36, backgroundColor: Colors.white24,
              child: Text((user['firstName'] as String? ?? 'U')[0].toUpperCase(),
                style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold)),
            ),
            const SizedBox(width: 14),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('${user['firstName']} ${user['lastName']}',
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18)),
              Text(user['email'] ?? '', style: const TextStyle(color: Colors.white70, fontSize: 12)),
              if (user['phone'] != null)
                Text(user['phone'], style: const TextStyle(color: Colors.white60, fontSize: 12)),
            ])),
            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              const Text('Loyalty', style: TextStyle(color: Colors.white60, fontSize: 10)),
              Text('${user['loyaltyPoints'] ?? 0}', style: const TextStyle(color: AppTheme.gold, fontWeight: FontWeight.w900, fontSize: 26)),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(10)),
                child: Text(user['tier'] ?? 'Blue',
                  style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600)),
              ),
            ]),
          ]),
        ),

        // Menu items
        const SizedBox(height: 8),
        _menuItem(context, Icons.confirmation_number_outlined, 'My Bookings', '/my-bookings'),
        _menuItem(context, Icons.check_circle_outline, 'Web Check-in', '/check-in'),
        _menuItem(context, Icons.flight_takeoff, 'Flight Status', '/flight-status'),
        _menuItem(context, Icons.local_offer_outlined, 'Offers & Deals', '/offers'),
        const Divider(),
        ListTile(
          leading: const Icon(Icons.logout, color: AppTheme.error),
          title: const Text('Sign Out', style: TextStyle(color: AppTheme.error, fontWeight: FontWeight.w600)),
          onTap: () async {
            await auth.logout();
            if (context.mounted) Navigator.pushNamedAndRemoveUntil(context, '/home', (_) => false);
          },
        ),
      ]),
    );
  }

  Widget _menuItem(BuildContext ctx, IconData icon, String title, String route) {
    return ListTile(
      leading: Icon(icon, color: AppTheme.primary),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w500)),
      trailing: const Icon(Icons.chevron_right, color: AppTheme.textGray),
      onTap: () => Navigator.pushNamed(ctx, route),
    );
  }
}
