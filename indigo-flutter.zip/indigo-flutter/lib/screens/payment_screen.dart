// lib/screens/payment_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../config/app_theme.dart';
import '../providers/booking_provider.dart';
import '../services/booking_service.dart';

class PaymentScreen extends StatefulWidget {
  const PaymentScreen({super.key});
  @override
  State<PaymentScreen> createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen> {
  String _method = 'card';
  bool _loading = false;
  final _promoCtrl = TextEditingController();
  String? _promoMsg;

  Future<void> _applyPromo() async {
    final bp = context.read<BookingProvider>();
    final res = await BookingService.validatePromo(
      code: _promoCtrl.text.trim().toUpperCase(),
      amount: bp.totalPrice,
    );
    if (res['success'] == true) {
      bp.applyPromo(_promoCtrl.text.trim().toUpperCase(), (res['discount'] as num).toDouble());
      setState(() => _promoMsg = '✓ Saved ₹${res['discount']}!');
    } else {
      setState(() => _promoMsg = res['message']);
    }
  }

  Future<void> _pay() async {
    final bp = context.read<BookingProvider>();
    setState(() => _loading = true);

    // 1. Create booking
    final createRes = await BookingService.createBooking(
      flightId: bp.selectedOutbound!.id,
      passengers: bp.passengerList,
      cabinClass: bp.cabinClass,
      contactEmail: bp.contactEmail,
      contactPhone: bp.contactPhone,
      returnFlightId: bp.selectedReturn?.id,
      addons: bp.addonsMap,
    );

    if (createRes['success'] != true) {
      setState(() => _loading = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(createRes['message'] ?? 'Booking failed')));
      return;
    }

    // 2. Confirm payment
    final bookingId = createRes['booking']['_id'];
    final confirmRes = await BookingService.confirmPayment(
      bookingId: bookingId,
      paymentMethod: _method,
    );

    setState(() => _loading = false);
    if (confirmRes['success'] == true) {
      final pnr = confirmRes['booking']['pnr'];
      bp.confirmedPNR = pnr;
      bp.reset();
      Navigator.pushNamedAndRemoveUntil(context, '/confirmation', (r) => r.settings.name == '/home',
        arguments: pnr,
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(confirmRes['message'] ?? 'Payment failed')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final bp = context.watch<BookingProvider>();
    final fmt = NumberFormat('#,##0', 'en_IN');

    return Scaffold(
      appBar: AppBar(title: const Text('Secure Payment')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Flight summary
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Row(children: [
                const Icon(Icons.flight_takeoff, color: AppTheme.primary),
                const SizedBox(width: 10),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('${bp.from} → ${bp.to}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                  Text('${bp.selectedOutbound?.flightNumber ?? ''} · ${bp.cabinClass} · ${bp.passengers} pax',
                    style: const TextStyle(fontSize: 12, color: AppTheme.textGray)),
                ])),
                Text('₹${fmt.format(bp.totalPrice)}',
                  style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18, color: AppTheme.primary)),
              ]),
            ),
          ),

          const SizedBox(height: 14),

          // Promo code
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Promo Code', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 10),
                Row(children: [
                  Expanded(child: TextField(
                    controller: _promoCtrl,
                    textCapitalization: TextCapitalization.characters,
                    decoration: const InputDecoration(hintText: 'Enter code', isDense: true),
                  )),
                  const SizedBox(width: 10),
                  OutlinedButton(onPressed: _applyPromo, child: const Text('Apply')),
                ]),
                if (_promoMsg != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Text(_promoMsg!, style: TextStyle(fontSize: 12,
                      color: _promoMsg!.startsWith('✓') ? AppTheme.success : AppTheme.error)),
                  ),
              ]),
            ),
          ),

          const SizedBox(height: 14),

          // Payment methods
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Payment Method', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 10),
                for (final m in [
                  {'key': 'card', 'icon': Icons.credit_card, 'label': 'Credit / Debit Card'},
                  {'key': 'upi', 'icon': Icons.phone_android, 'label': 'UPI'},
                  {'key': 'netbanking', 'icon': Icons.account_balance, 'label': 'Net Banking'},
                  {'key': 'wallet', 'icon': Icons.account_balance_wallet, 'label': 'Wallet'},
                ])
                  RadioListTile<String>(
                    value: m['key'] as String,
                    groupValue: _method,
                    onChanged: (v) => setState(() => _method = v!),
                    title: Row(children: [
                      Icon(m['icon'] as IconData, size: 18, color: AppTheme.textGray),
                      const SizedBox(width: 8),
                      Text(m['label'] as String, style: const TextStyle(fontSize: 14)),
                    ]),
                    contentPadding: EdgeInsets.zero,
                    activeColor: AppTheme.primary,
                  ),
              ]),
            ),
          ),

          const SizedBox(height: 14),
          const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(Icons.lock, size: 14, color: AppTheme.textGray),
            SizedBox(width: 4),
            Text('256-bit SSL encrypted · Secure payment', style: TextStyle(fontSize: 12, color: AppTheme.textGray)),
          ]),
          const SizedBox(height: 80),
        ],
      ),
      bottomNavigationBar: Container(
        padding: const EdgeInsets.all(16),
        color: Colors.white,
        child: ElevatedButton(
          onPressed: _loading ? null : _pay,
          style: ElevatedButton.styleFrom(backgroundColor: AppTheme.accent),
          child: _loading
              ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
              : Text('Pay ₹${fmt.format(bp.totalPrice)}', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
        ),
      ),
    );
  }
}
