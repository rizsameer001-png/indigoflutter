// lib/screens/check_in_screen.dart
import 'package:flutter/material.dart';
import '../config/app_theme.dart';
import '../services/booking_service.dart';

class CheckInScreen extends StatefulWidget {
  const CheckInScreen({super.key});
  @override State<CheckInScreen> createState() => _CheckInScreenState();
}
class _CheckInScreenState extends State<CheckInScreen> {
  final _pnrCtrl  = TextEditingController();
  final _nameCtrl = TextEditingController();
  bool _loading = false;
  Map<String, dynamic>? _pass;

  Future<void> _checkIn() async {
    if (_pnrCtrl.text.isEmpty || _nameCtrl.text.isEmpty) return;
    setState(() { _loading = true; });
    final res = await BookingService.webCheckIn(pnr: _pnrCtrl.text.trim().toUpperCase(), lastName: _nameCtrl.text.trim());
    setState(() {
      _loading = false;
      if (res['success'] == true) _pass = res['boardingPass'];
      else ScaffoldMessenger.of(context as BuildContext).showSnackBar(SnackBar(content: Text(res['message'] ?? 'Check-in failed')));
    });
  }

  @override
  Widget build(BuildContext ctx) {
    return Scaffold(
      appBar: AppBar(title: const Text('Web Check-In')),
      body: Padding(padding: const EdgeInsets.all(16), child: _pass == null ? Column(children: [
        const Text('Check-in opens 48 hours before departure', style: TextStyle(color: AppTheme.textGray)),
        const SizedBox(height: 20),
        TextField(controller: _pnrCtrl, textCapitalization: TextCapitalization.characters,
          decoration: const InputDecoration(labelText: 'PNR', hintText: 'e.g. AB1C2D'),
          style: const TextStyle(fontFamily: 'monospace', fontWeight: FontWeight.bold, fontSize: 18)),
        const SizedBox(height: 12),
        TextField(controller: _nameCtrl, decoration: const InputDecoration(labelText: 'Last Name')),
        const SizedBox(height: 20),
        ElevatedButton.icon(onPressed: _loading ? null : _checkIn, icon: const Icon(Icons.check_circle_outline), label: const Text('Check In Now')),
      ]) : _BoardingPass(pass: _pass!)),
    );
  }
}

class _BoardingPass extends StatelessWidget {
  final Map<String, dynamic> pass;
  const _BoardingPass({required this.pass});
  @override
  Widget build(BuildContext context) => Card(
    color: const Color(0xFFF0F6FF),
    child: Padding(padding: const EdgeInsets.all(20), child: Column(children: [
      const Icon(Icons.airplane_ticket, size: 52, color: AppTheme.primary),
      const SizedBox(height: 12),
      const Text('Check-in Confirmed! ✓', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: AppTheme.success)),
      const SizedBox(height: 16),
      _row('Passenger', pass['passenger']),
      _row('Flight', pass['flight']),
      _row('PNR', pass['pnr']),
      _row('Seat', pass['seat']),
      _row('Gate', pass['gate']),
    ])),
  );

  Widget _row(String label, dynamic value) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 6),
    child: Row(children: [
      Text('$label:', style: const TextStyle(color: AppTheme.textGray, fontWeight: FontWeight.w500)),
      const SizedBox(width: 8),
      Text('${value ?? 'TBA'}', style: const TextStyle(fontWeight: FontWeight.bold)),
    ]),
  );
}

// lib/screens/flight_status_screen.dart
class FlightStatusScreen extends StatefulWidget {
  const FlightStatusScreen({super.key});
  @override State<FlightStatusScreen> createState() => _FlightStatusScreenState();
}
class _FlightStatusScreenState extends State<FlightStatusScreen> {
  final _numCtrl  = TextEditingController();
  bool _loading = false;
  Map<String, dynamic>? _status;

  Future<void> _check() async {
    if (_numCtrl.text.isEmpty) return;
    setState(() { _loading = true; _status = null; });
    final res = await FlightService.getFlightStatus(flightNumber: _numCtrl.text.trim().toUpperCase());
    setState(() {
      _loading = false;
      if (res['success'] == true) _status = res;
    });
    if (res['success'] != true) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(res['message'] ?? 'Not found')));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Flight Status')),
    body: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Expanded(child: TextField(controller: _numCtrl, textCapitalization: TextCapitalization.characters,
          decoration: const InputDecoration(labelText: 'Flight Number', hintText: 'e.g. 6E101'))),
        const SizedBox(width: 10),
        ElevatedButton(onPressed: _loading ? null : _check, style: ElevatedButton.styleFrom(minimumSize: const Size(90, 50)),
          child: _loading ? const SizedBox(h:20,w:20,child:CircularProgressIndicator(color:Colors.white,strokeWidth:2)) as Widget : const Text('Check')),
      ]),
      if (_status != null) ...[
        const SizedBox(height: 20),
        Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text(_status!['flightNumber'] ?? '', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 24, color: AppTheme.primary)),
            _statusChip(_status!['status'] ?? ''),
          ]),
          const SizedBox(height: 16),
          Row(children: [
            Expanded(child: Column(children: [
              Text(_status!['origin']?['code'] ?? '', style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
              Text(_status!['origin']?['city'] ?? '', style: const TextStyle(color: AppTheme.textGray)),
            ])),
            const Icon(Icons.flight, color: AppTheme.primary, size: 32),
            Expanded(child: Column(children: [
              Text(_status!['destination']?['code'] ?? '', style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
              Text(_status!['destination']?['city'] ?? '', style: const TextStyle(color: AppTheme.textGray)),
            ])),
          ]),
        ]))),
      ],
    ])),
  );

  Widget _statusChip(String s) {
    final c = s == 'On Time' || s == 'Arrived' ? AppTheme.success : s == 'Delayed' ? Colors.orange : s == 'Cancelled' ? AppTheme.error : AppTheme.primary;
    return Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(color: c.withOpacity(0.1), borderRadius: BorderRadius.circular(20)),
      child: Text(s, style: TextStyle(color: c, fontWeight: FontWeight.bold)));
  }
}

import '../services/flight_service.dart';
