// lib/screens/confirmation_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../config/app_theme.dart';

class ConfirmationScreen extends StatelessWidget {
  const ConfirmationScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final pnr = ModalRoute.of(context)?.settings.arguments as String? ?? '------';
    return Scaffold(
      appBar: AppBar(title: const Text('Booking Confirmed!')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const SizedBox(height: 20),
          const Text('🎉', textAlign: TextAlign.center, style: TextStyle(fontSize: 72)),
          const SizedBox(height: 16),
          const Text('Booking Confirmed!', textAlign: TextAlign.center, style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('Have a great flight!', textAlign: TextAlign.center, style: TextStyle(color: AppTheme.textGray, fontSize: 15)),
          const SizedBox(height: 32),
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: const Color(0xFFF0F6FF),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppTheme.primary.withOpacity(0.3)),
            ),
            child: Column(children: [
              const Text('PNR / Booking Reference', style: TextStyle(fontSize: 12, color: AppTheme.textGray, letterSpacing: 1)),
              const SizedBox(height: 6),
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Text(pnr, style: const TextStyle(fontSize: 36, fontWeight: FontWeight.w900, color: AppTheme.primary, letterSpacing: 4, fontFamily: 'monospace')),
                const SizedBox(width: 8),
                IconButton(
                  onPressed: () { Clipboard.setData(ClipboardData(text: pnr)); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('PNR copied!'))); },
                  icon: const Icon(Icons.copy, color: AppTheme.textGray, size: 20),
                ),
              ]),
            ]),
          ),
          const SizedBox(height: 24),
          for (final tip in [
            ('📧', 'Check your email', 'Booking confirmation sent to your email'),
            ('⏰', 'Web Check-in', 'Opens 48 hours before departure'),
            ('🛄', 'Baggage', 'Arrive early for baggage drop'),
            ('📱', 'App', 'Show this PNR at the counter'),
          ])
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Row(children: [
                Text(tip.$1, style: const TextStyle(fontSize: 24)),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(tip.$2, style: const TextStyle(fontWeight: FontWeight.w600)),
                  Text(tip.$3, style: const TextStyle(fontSize: 12, color: AppTheme.textGray)),
                ])),
              ]),
            ),
          const SizedBox(height: 24),
          OutlinedButton.icon(
            onPressed: () => Navigator.pushNamed(context, '/check-in'),
            icon: const Icon(Icons.check_circle_outline),
            label: const Text('Web Check-in'),
          ),
          const SizedBox(height: 10),
          ElevatedButton.icon(
            onPressed: () => Navigator.pushNamedAndRemoveUntil(context, '/home', (_) => false),
            icon: const Icon(Icons.home),
            label: const Text('Back to Home'),
          ),
        ],
      ),
    );
  }
}
