// lib/screens/manage_booking_screen.dart
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../config/app_theme.dart';
import '../services/booking_service.dart';

class ManageBookingScreen extends StatefulWidget {
  const ManageBookingScreen({super.key});
  @override State<ManageBookingScreen> createState() => _ManageBookingScreenState();
}
class _ManageBookingScreenState extends State<ManageBookingScreen> {
  final _pnrCtrl = TextEditingController();
  Map<String, dynamic>? _booking;
  bool _loading = false;
  String? _error;

  Future<void> _find() async {
    if (_pnrCtrl.text.isEmpty) return;
    setState(() { _loading = true; _error = null; });
    final res = await BookingService.getBookingByPNR(_pnrCtrl.text.trim().toUpperCase());
    setState(() {
      _loading = false;
      if (res['success'] == true) { _booking = res['booking']; }
      else { _error = res['message']; }
    });
  }

  Future<void> _cancel() async {
    if (_booking == null) return;
    final confirm = await showDialog<bool>(context: context,
      builder: (_) => AlertDialog(
        title: const Text('Cancel Booking?'),
        content: const Text('This action cannot be undone. Any refund will be processed per policy.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('No')),
          TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Yes, Cancel', style: TextStyle(color: AppTheme.error))),
        ],
      ),
    );
    if (confirm != true) return;
    final res = await BookingService.cancelBooking(_booking!['_id']);
    if (res['success'] == true) setState(() => _booking!['status'] = 'Cancelled');
    else ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(res['message'] ?? 'Cancel failed')));
  }

  @override
  Widget build(BuildContext context) {
    final flight = _booking?['trip']?['outbound'];
    return Scaffold(
      appBar: AppBar(title: const Text('Manage Booking')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Enter PNR to retrieve booking', style: TextStyle(color: AppTheme.textGray)),
          const SizedBox(height: 14),
          Row(children: [
            Expanded(child: TextField(
              controller: _pnrCtrl,
              textCapitalization: TextCapitalization.characters,
              style: const TextStyle(fontFamily: 'monospace', fontWeight: FontWeight.bold, fontSize: 18, letterSpacing: 2),
              decoration: const InputDecoration(labelText: 'PNR / Reference', hintText: 'e.g. AB1C2D'),
            )),
            const SizedBox(width: 10),
            ElevatedButton(onPressed: _loading ? null : _find,
              style: ElevatedButton.styleFrom(minimumSize: const Size(90, 50)),
              child: _loading ? const SizedBox(h:20,w:20,child:CircularProgressIndicator(color:Colors.white,strokeWidth:2)) as Widget : const Text('Find')),
          ]),
          if (_error != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(_error!, style: const TextStyle(color: AppTheme.error))),
          if (_booking != null) ...[
            const SizedBox(height: 20),
            Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Text(_booking!['pnr'], style: const TextStyle(fontFamily: 'monospace', fontWeight: FontWeight.w900, fontSize: 26, color: AppTheme.primary, letterSpacing: 2)),
                _statusBadge(_booking!['status']),
              ]),
              const SizedBox(height: 12),
              if (flight != null) Container(
                padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: const Color(0xFFF0F6FF), borderRadius: BorderRadius.circular(10)),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('${flight['origin']?['city']} → ${flight['destination']?['city']}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                  const SizedBox(height: 4),
                  Text('${flight['flightNumber']} · ${_booking!['class']}', style: const TextStyle(color: AppTheme.textGray, fontSize: 13)),
                ]),
              ),
              const SizedBox(height: 12),
              for (final p in (_booking!['passengers'] as List? ?? []))
                Padding(padding: const EdgeInsets.symmetric(vertical: 3),
                  child: Text('${p['title']} ${p['firstName']} ${p['lastName']}', style: const TextStyle(fontSize: 14))),
              const Divider(),
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                const Text('Total Paid', style: TextStyle(fontWeight: FontWeight.bold)),
                Text('₹${NumberFormat('#,##0').format(_booking!['pricing']?['total'] ?? 0)}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18, color: AppTheme.primary)),
              ]),
              if (_booking!['status'] == 'Confirmed') ...[
                const SizedBox(height: 12),
                OutlinedButton.icon(onPressed: _cancel, icon: const Icon(Icons.cancel_outlined, color: AppTheme.error), label: const Text('Cancel Booking', style: TextStyle(color: AppTheme.error)),
                  style: OutlinedButton.styleFrom(side: const BorderSide(color: AppTheme.error))),
              ],
            ]))),
          ],
        ]),
      ),
    );
  }

  Widget _statusBadge(String status) {
    final colors = {'Confirmed': Colors.green, 'Cancelled': AppTheme.error, 'Pending': Colors.orange};
    final c = colors[status] ?? AppTheme.textGray;
    return Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(color: c.withOpacity(0.1), borderRadius: BorderRadius.circular(20)),
      child: Text(status, style: TextStyle(color: c, fontWeight: FontWeight.bold, fontSize: 12)));
  }
}
