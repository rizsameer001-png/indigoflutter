// lib/screens/offers_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../config/app_theme.dart';
import '../services/offer_service.dart';

class OffersScreen extends StatefulWidget {
  const OffersScreen({super.key});
  @override State<OffersScreen> createState() => _OffersScreenState();
}
class _OffersScreenState extends State<OffersScreen> {
  List<Map<String, dynamic>> _offers = [];
  bool _loading = true;
  String _copied = '';

  @override
  void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final data = await OfferService.getOffers();
    if (mounted) setState(() { _offers = data; _loading = false; });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Offers & Deals')),
    body: _loading ? const Center(child: CircularProgressIndicator()) :
      _offers.isEmpty ? const Center(child: Text('No offers right now')) :
      ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _offers.length,
        itemBuilder: (_, i) {
          final o = _offers[i];
          final isFlat = o['discountType'] == 'Flat';
          return Container(
            margin: const EdgeInsets.only(bottom: 14),
            decoration: BoxDecoration(
              color: Colors.white, borderRadius: BorderRadius.circular(14),
              border: const Border(left: BorderSide(color: AppTheme.primary, width: 4)),
              boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8, offset: const Offset(0,2))],
            ),
            child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(child: Text(o['title'] ?? '', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16))),
                Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(color: AppTheme.primary, borderRadius: BorderRadius.circular(20)),
                  child: Text(isFlat ? '₹${o['discountValue']} OFF' : '${o['discountValue']}% OFF',
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12))),
              ]),
              const SizedBox(height: 6),
              Text(o['description'] ?? '', style: const TextStyle(color: AppTheme.textGray, fontSize: 13)),
              const SizedBox(height: 12),
              Row(children: [
                Expanded(child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(color: const Color(0xFFF0F6FF), borderRadius: BorderRadius.circular(8)),
                  child: Text(o['code'] ?? '', style: const TextStyle(fontFamily: 'monospace', fontWeight: FontWeight.w800, fontSize: 16, color: AppTheme.primary, letterSpacing: 2)),
                )),
                const SizedBox(width: 10),
                TextButton.icon(
                  onPressed: () {
                    Clipboard.setData(ClipboardData(text: o['code']));
                    setState(() => _copied = o['code']);
                    Future.delayed(const Duration(seconds: 2), () { if (mounted) setState(() => _copied = ''); });
                  },
                  icon: Icon(_copied == o['code'] ? Icons.check : Icons.copy, size: 16),
                  label: Text(_copied == o['code'] ? 'Copied!' : 'Copy'),
                ),
              ]),
              const SizedBox(height: 8),
              Text('Min booking: ₹${o['minBookingAmount']} · Valid till ${(o['validTill'] ?? '').toString().split('T')[0]}',
                style: const TextStyle(fontSize: 11, color: AppTheme.textGray)),
            ])),
          );
        },
      ),
  );
}
