// lib/screens/addons_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../config/app_theme.dart';
import '../providers/booking_provider.dart';

class AddonsScreen extends StatelessWidget {
  const AddonsScreen({super.key});

  static const _addons = [
    {'key': 'extraBaggage', 'icon': '🧳', 'title': 'Extra Baggage', 'desc': '+15kg check-in baggage', 'price': 599, 'tag': 'Popular'},
    {'key': 'mealPlan', 'icon': '🍱', 'title': 'Meal Plan', 'desc': 'Pre-order delicious meals', 'price': 299, 'tag': ''},
    {'key': 'seatSelection', 'icon': '💺', 'title': 'Seat Selection', 'desc': 'Choose your preferred seat', 'price': 199, 'tag': 'Recommended'},
    {'key': 'travelInsurance', 'icon': '🛡️', 'title': 'Travel Insurance', 'desc': 'Comprehensive travel cover', 'price': 499, 'tag': ''},
    {'key': 'priorityBoarding', 'icon': '⚡', 'title': 'Priority Boarding', 'desc': 'Board first, avoid queues', 'price': 199, 'tag': ''},
  ];

  @override
  Widget build(BuildContext context) {
    final bp = context.watch<BookingProvider>();
    final fmt = NumberFormat('#,##0', 'en_IN');

    return Scaffold(
      appBar: AppBar(title: const Text('Add-ons')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('🎁 Enhance Your Journey', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          const Text('Make your trip more comfortable', style: TextStyle(color: AppTheme.textGray)),
          const SizedBox(height: 16),
          for (final a in _addons)
            _AddonTile(
              icon: a['icon'] as String,
              title: a['title'] as String,
              desc: a['desc'] as String,
              price: a['price'] as int,
              tag: a['tag'] as String,
              selected: bp.addonsMap[a['key']] ?? false,
              onTap: () => bp.toggleAddon(a['key'] as String),
              passengers: bp.passengers,
            ),
          const SizedBox(height: 16),
          // Price summary card
          Card(
            color: const Color(0xFFF0F6FF),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(children: [
                const Row(children: [
                  Icon(Icons.receipt_long, color: AppTheme.primary, size: 18),
                  SizedBox(width: 6),
                  Text('Price Summary', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                ]),
                const SizedBox(height: 12),
                _summaryRow('Base Fare', '₹${fmt.format(bp.selectedOutbound?.priceFor(bp.cabinClass) != null ? bp.selectedOutbound!.priceFor(bp.cabinClass) * bp.passengers : 0)}'),
                if (bp.addonsCost > 0) _summaryRow('Add-ons', '+₹${fmt.format(bp.addonsCost)}', color: AppTheme.primary),
                if (bp.discount > 0) _summaryRow('Discount', '-₹${fmt.format(bp.discount)}', color: AppTheme.success),
                const Divider(),
                Row(children: [
                  const Text('Total', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                  const Spacer(),
                  Text('₹${fmt.format(bp.totalPrice)}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 20, color: AppTheme.primary)),
                ]),
              ]),
            ),
          ),
          const SizedBox(height: 80),
        ],
      ),
      bottomNavigationBar: Container(
        padding: const EdgeInsets.all(16),
        color: Colors.white,
        child: ElevatedButton(
          onPressed: () => Navigator.pushNamed(context, '/payment'),
          child: Text('Proceed to Payment  ₹${fmt.format(bp.totalPrice)}'),
        ),
      ),
    );
  }

  Widget _summaryRow(String label, String value, {Color? color}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(children: [
        Text(label, style: const TextStyle(fontSize: 14)),
        const Spacer(),
        Text(value, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: color)),
      ]),
    );
  }
}

class _AddonTile extends StatelessWidget {
  final String icon, title, desc, tag;
  final int price;
  final bool selected;
  final VoidCallback onTap;
  final int passengers;

  const _AddonTile({
    required this.icon, required this.title, required this.desc,
    required this.tag, required this.price, required this.selected,
    required this.onTap, required this.passengers,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFFF0F6FF) : Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: selected ? AppTheme.primary : AppTheme.border, width: selected ? 2 : 1.5),
        ),
        child: Row(children: [
          Text(icon, style: const TextStyle(fontSize: 28)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Text(title, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
              if (tag.isNotEmpty) ...[
                const SizedBox(width: 6),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(color: AppTheme.primary, borderRadius: BorderRadius.circular(10)),
                  child: Text(tag, style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.bold)),
                ),
              ],
            ]),
            Text(desc, style: const TextStyle(fontSize: 12, color: AppTheme.textGray)),
          ])),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text('₹$price', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15, color: AppTheme.primary)),
            Text('/pax', style: const TextStyle(fontSize: 11, color: AppTheme.textGray)),
          ]),
          const SizedBox(width: 10),
          AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            width: 26, height: 26,
            decoration: BoxDecoration(
              color: selected ? AppTheme.primary : Colors.transparent,
              shape: BoxShape.circle,
              border: Border.all(color: selected ? AppTheme.primary : AppTheme.border, width: 2),
            ),
            alignment: Alignment.center,
            child: Icon(selected ? Icons.check : Icons.add, color: selected ? Colors.white : AppTheme.textGray, size: 14),
          ),
        ]),
      ),
    );
  }
}
