// lib/screens/passenger_details_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../config/app_theme.dart';
import '../providers/booking_provider.dart';
import '../models/booking_model.dart';

class PassengerDetailsScreen extends StatefulWidget {
  const PassengerDetailsScreen({super.key});
  @override
  State<PassengerDetailsScreen> createState() => _PassengerDetailsScreenState();
}

class _PassengerDetailsScreenState extends State<PassengerDetailsScreen> {
  final _formKey = GlobalKey<FormState>();
  late List<Map<String, dynamic>> _paxData;
  final _emailCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();

  static const _titles = ['Mr', 'Mrs', 'Ms', 'Dr', 'Master', 'Miss'];
  static const _meals  = ['None', 'Veg', 'Non-Veg', 'Jain'];

  @override
  void initState() {
    super.initState();
    final count = context.read<BookingProvider>().passengers;
    _paxData = List.generate(count, (_) => {
      'title': 'Mr', 'firstName': '', 'lastName': '',
      'gender': 'Male', 'nationality': 'Indian',
      'type': 'Adult', 'mealPreference': 'None',
    });
  }

  void _submit() {
    if (!_formKey.currentState!.validate()) return;
    _formKey.currentState!.save();

    final passengers = _paxData.map((p) => Passenger(
      title: p['title'],
      firstName: p['firstName'],
      lastName: p['lastName'],
      gender: p['gender'],
      nationality: p['nationality'],
      type: p['type'],
      mealPreference: p['mealPreference'],
    )).toList();

    final bp = context.read<BookingProvider>();
    bp.setPassengers(passengers);
    bp.setContact(_emailCtrl.text.trim(), _phoneCtrl.text.trim());
    Navigator.pushNamed(context, '/addons');
  }

  @override
  Widget build(BuildContext context) {
    final bp = context.watch<BookingProvider>();
    return Scaffold(
      appBar: AppBar(title: const Text('Passenger Details')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _stepIndicator(2),
            const SizedBox(height: 16),
            for (int i = 0; i < _paxData.length; i++) ...[
              _paxCard(i),
              const SizedBox(height: 12),
            ],
            _contactCard(),
            const SizedBox(height: 80),
          ],
        ),
      ),
      bottomNavigationBar: Container(
        padding: const EdgeInsets.all(16),
        color: Colors.white,
        child: ElevatedButton(
          onPressed: _submit,
          child: const Text('Continue to Add-ons →'),
        ),
      ),
    );
  }

  Widget _paxCard(int i) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Icon(Icons.person, color: AppTheme.primary, size: 18),
            const SizedBox(width: 6),
            Text('Passenger ${i + 1}', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
          ]),
          const SizedBox(height: 14),
          Row(children: [
            SizedBox(
              width: 90,
              child: DropdownButtonFormField<String>(
                value: _paxData[i]['title'],
                items: _titles.map((t) => DropdownMenuItem(value: t, child: Text(t))).toList(),
                onChanged: (v) => setState(() => _paxData[i]['title'] = v),
                decoration: const InputDecoration(labelText: 'Title'),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(child: TextFormField(
              decoration: const InputDecoration(labelText: 'First Name *'),
              onSaved: (v) => _paxData[i]['firstName'] = v?.trim() ?? '',
              validator: (v) => v?.isEmpty == true ? 'Required' : null,
            )),
          ]),
          const SizedBox(height: 10),
          TextFormField(
            decoration: const InputDecoration(labelText: 'Last Name *'),
            onSaved: (v) => _paxData[i]['lastName'] = v?.trim() ?? '',
            validator: (v) => v?.isEmpty == true ? 'Required' : null,
          ),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(child: DropdownButtonFormField<String>(
              value: _paxData[i]['gender'],
              items: ['Male', 'Female', 'Other'].map((g) => DropdownMenuItem(value: g, child: Text(g))).toList(),
              onChanged: (v) => setState(() => _paxData[i]['gender'] = v),
              decoration: const InputDecoration(labelText: 'Gender'),
            )),
            const SizedBox(width: 10),
            Expanded(child: DropdownButtonFormField<String>(
              value: _paxData[i]['mealPreference'],
              items: _meals.map((m) => DropdownMenuItem(value: m, child: Text(m))).toList(),
              onChanged: (v) => setState(() => _paxData[i]['mealPreference'] = v),
              decoration: const InputDecoration(labelText: 'Meal'),
            )),
          ]),
        ]),
      ),
    );
  }

  Widget _contactCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Row(children: [
            Icon(Icons.contact_mail, color: AppTheme.primary, size: 18),
            SizedBox(width: 6),
            Text('Contact Information', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
          ]),
          const SizedBox(height: 6),
          const Text('Booking confirmation will be sent here', style: TextStyle(color: AppTheme.textGray, fontSize: 12)),
          const SizedBox(height: 14),
          TextFormField(
            controller: _emailCtrl,
            keyboardType: TextInputType.emailAddress,
            decoration: const InputDecoration(labelText: 'Email Address *', prefixIcon: Icon(Icons.email_outlined)),
            validator: (v) => v?.contains('@') == true ? null : 'Enter valid email',
          ),
          const SizedBox(height: 10),
          TextFormField(
            controller: _phoneCtrl,
            keyboardType: TextInputType.phone,
            decoration: const InputDecoration(labelText: 'Mobile Number *', prefixIcon: Icon(Icons.phone_outlined)),
            validator: (v) => (v?.length ?? 0) >= 10 ? null : 'Enter valid phone',
          ),
        ]),
      ),
    );
  }

  Widget _stepIndicator(int current) {
    final steps = ['Flights', 'Passengers', 'Add-ons', 'Payment'];
    return Row(
      children: List.generate(steps.length * 2 - 1, (i) {
        if (i.isOdd) {
          return Expanded(child: Container(height: 2, color: i ~/ 2 < current - 1 ? AppTheme.success : AppTheme.border));
        }
        final step = i ~/ 2 + 1;
        final done = step < current;
        final active = step == current;
        return Container(
          width: 28, height: 28,
          decoration: BoxDecoration(
            color: done ? AppTheme.success : active ? AppTheme.primary : Colors.white,
            shape: BoxShape.circle,
            border: Border.all(color: done ? AppTheme.success : active ? AppTheme.primary : AppTheme.border, width: 2),
          ),
          alignment: Alignment.center,
          child: done
              ? const Icon(Icons.check, color: Colors.white, size: 14)
              : Text('$step', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: active ? Colors.white : AppTheme.textGray)),
        );
      }),
    );
  }
}
