// lib/screens/flight_status_screen.dart
import 'package:flutter/material.dart';
import '../config/app_theme.dart';
import '../services/flight_service.dart';

class FlightStatusScreen extends StatefulWidget {
  const FlightStatusScreen({super.key});
  @override State<FlightStatusScreen> createState() => _FlightStatusScreenState();
}
class _FlightStatusScreenState extends State<FlightStatusScreen> {
  final _ctrl = TextEditingController();
  bool _loading = false;
  Map<String, dynamic>? _status;
  String? _error;

  Future<void> _check() async {
    if (_ctrl.text.isEmpty) return;
    setState(() { _loading = true; _error = null; _status = null; });
    final res = await FlightService.getFlightStatus(flightNumber: _ctrl.text.trim().toUpperCase());
    setState(() {
      _loading = false;
      if (res['success'] == true) _status = res;
      else _error = res['message'];
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Flight Status')),
    body: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Enter flight number to check real-time status', style: TextStyle(color: AppTheme.textGray)),
      const SizedBox(height: 14),
      Row(children: [
        Expanded(child: TextField(controller: _ctrl, textCapitalization: TextCapitalization.characters,
          decoration: const InputDecoration(labelText: 'Flight Number', hintText: 'e.g. 6E101', prefixIcon: Icon(Icons.flight)))),
        const SizedBox(width: 10),
        ElevatedButton(onPressed: _loading ? null : _check,
          style: ElevatedButton.styleFrom(minimumSize: const Size(90, 52)),
          child: _loading ? const SizedBox(height:20,width:20,child:CircularProgressIndicator(color:Colors.white,strokeWidth:2)) : const Text('Check')),
      ]),
      if (_error != null) Padding(padding: const EdgeInsets.only(top:12), child: Text(_error!, style: const TextStyle(color: AppTheme.error))),
      if (_status != null) ...[
        const SizedBox(height: 24),
        Card(child: Padding(padding: const EdgeInsets.all(20), child: Column(children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(_status!['flightNumber'] ?? '', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 28, color: AppTheme.primary)),
              const Text('IndiGo · Airbus A320', style: TextStyle(color: AppTheme.textGray, fontSize: 12)),
            ]),
            _chip(_status!['status'] ?? ''),
          ]),
          const SizedBox(height: 20),
          Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: const Color(0xFFF0F6FF), borderRadius: BorderRadius.circular(12)),
            child: Row(children: [
              Expanded(child: Column(children: [
                Text(_status!['origin']?['code'] ?? '', style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
                Text(_status!['origin']?['city'] ?? '', style: const TextStyle(color: AppTheme.textGray, fontSize: 12)),
              ])),
              const Icon(Icons.flight, color: AppTheme.primary, size: 28),
              Expanded(child: Column(children: [
                Text(_status!['destination']?['code'] ?? '', style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
                Text(_status!['destination']?['city'] ?? '', style: const TextStyle(color: AppTheme.textGray, fontSize: 12)),
              ])),
            ])),
        ]))),
      ],
    ])),
  );

  Widget _chip(String s) {
    final map = {'On Time': AppTheme.success, 'Scheduled': AppTheme.primary, 'Delayed': Colors.orange, 'Cancelled': AppTheme.error, 'Boarding': Colors.blue, 'Arrived': AppTheme.success};
    final c = map[s] ?? AppTheme.textGray;
    return Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6), decoration: BoxDecoration(color: c.withOpacity(0.12), borderRadius: BorderRadius.circular(20)),
      child: Text(s, style: TextStyle(color: c, fontWeight: FontWeight.bold, fontSize: 13)));
  }
}
