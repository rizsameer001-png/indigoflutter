import React from 'react';
import ReactDOM from 'react-dom/client';
import './styles/globals.css';
import 'react-datepicker/dist/react-datepicker.css';
import App from './App.jsx';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
